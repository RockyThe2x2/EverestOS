#!/usr/bin/env bash
# Creates a VirtualBox VM tuned for EverestOS and attaches the ISO.
#   ./tools/create-vbox-vm.sh output/EverestOS-1.0-amd64.iso [VM_NAME]
# Environment: FIRMWARE=efi|bios (default efi)  RAM_MB=4096  CPUS=2  DISK_MB=25600
set -euo pipefail
ISO="${1:?usage: $0 <path-to.iso> [vm-name]}"
NAME="${2:-EverestOS}"
FIRMWARE="${FIRMWARE:-efi}"
RAM_MB="${RAM_MB:-4096}"
CPUS="${CPUS:-2}"
DISK_MB="${DISK_MB:-25600}"
[ -f "$ISO" ] || { echo "ISO not found: $ISO" >&2; exit 1; }
command -v VBoxManage >/dev/null || { echo "VBoxManage not found: install VirtualBox first" >&2; exit 1; }

VBoxManage createvm --name "$NAME" --ostype Debian_64 --register
DIR="$(VBoxManage showvminfo "$NAME" --machinereadable | sed -n 's/^CfgFile="\(.*\)\/[^/]*"$/\1/p')"

VBoxManage modifyvm "$NAME" --memory "$RAM_MB" --cpus "$CPUS" --vram 128 \
    --graphicscontroller vmsvga --firmware "$FIRMWARE" --ioapic on --rtcuseutc on \
    --mouse usbtablet --nic1 nat --boot1 dvd --boot2 disk --boot3 none --boot4 none
# the clipboard option was renamed in VirtualBox 7
VBoxManage modifyvm "$NAME" --clipboard-mode bidirectional 2>/dev/null \
    || VBoxManage modifyvm "$NAME" --clipboard bidirectional || true

VBoxManage createmedium disk --filename "$DIR/$NAME.vdi" --size "$DISK_MB" --format VDI
VBoxManage storagectl "$NAME" --name SATA --add sata --controller IntelAhci --portcount 2
VBoxManage storageattach "$NAME" --storagectl SATA --port 0 --device 0 --type hdd --medium "$DIR/$NAME.vdi"
VBoxManage storageattach "$NAME" --storagectl SATA --port 1 --device 0 --type dvddrive --medium "$ISO"

echo
echo "VM '$NAME' created ($FIRMWARE, ${RAM_MB} MB RAM, $CPUS CPUs, ${DISK_MB} MB disk)."
echo "Start it with:  VBoxManage startvm \"$NAME\""
echo "After installing: Devices > Optical Drives > Remove disk from virtual drive."
