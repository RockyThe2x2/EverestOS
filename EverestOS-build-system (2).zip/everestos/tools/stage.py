#!/usr/bin/env python3
"""Assemble live-build's config/includes.chroot (files copied into the ISO's filesystem).

usage: stage.py <live-build-dir>
"""
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "installer"))

from everestos import i18n, theme  # noqa: E402
from everestos.state import SetupState  # noqa: E402

EXECUTABLE = (
    "usr/bin/everestos-setup", "usr/bin/everestos-search", "usr/bin/everestos-layout",
    "usr/bin/everestos-guest-additions", "usr/lib/everestos/launch-installer",
    "usr/lib/everestos/lockclock", "etc/skel/Desktop/everestos-install.desktop",
)


def merge_tree(src, dst):
    for dirpath, dirnames, filenames in os.walk(src):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        rel = os.path.relpath(dirpath, src)
        target = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(target, exist_ok=True)
        for f in filenames:
            if f.endswith(".pyc"):
                continue
            shutil.copy2(os.path.join(dirpath, f), os.path.join(target, f))


def put(rel, text, mode=0o644, inc=None):
    path = os.path.join(inc, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.chmod(path, mode)


def main(lb_dir):
    inc = os.path.join(lb_dir, "config", "includes.chroot")
    shutil.rmtree(inc, ignore_errors=True)
    os.makedirs(inc)

    # 1) generated artwork
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.check_call([sys.executable, os.path.join(ROOT, "assets", "make_assets.py"), tmp])
        merge_tree(os.path.join(tmp, "icons"), os.path.join(inc, "usr/share/icons"))
        merge_tree(os.path.join(tmp, "backgrounds"), os.path.join(inc, "usr/share/backgrounds/everestos"))
        merge_tree(os.path.join(tmp, "plymouth"), os.path.join(inc, "usr/share/plymouth/themes/everestos"))
        merge_tree(os.path.join(tmp, "calamares"), os.path.join(inc, "etc/calamares/branding/everestos"))

    # 2) the EverestOS python package, launchers, translations
    merge_tree(os.path.join(ROOT, "installer", "everestos"), os.path.join(inc, "usr/share/everestos/everestos"))
    merge_tree(os.path.join(ROOT, "installer", "bin"), os.path.join(inc, "usr/bin"))
    os.makedirs(os.path.join(inc, "usr/lib/everestos"), exist_ok=True)
    shutil.copy2(os.path.join(ROOT, "installer", "launch-installer"), os.path.join(inc, "usr/lib/everestos/launch-installer"))
    i18n.export_po(os.path.join(inc, "usr/share/everestos/po"))

    # 3) Calamares
    cal = os.path.join(ROOT, "calamares")
    os.makedirs(os.path.join(inc, "etc/calamares"), exist_ok=True)
    shutil.copy2(os.path.join(cal, "settings.conf"), os.path.join(inc, "etc/calamares/settings.conf"))
    merge_tree(os.path.join(cal, "modules"), os.path.join(inc, "etc/calamares/modules"))
    merge_tree(os.path.join(cal, "modules-py", "everestos"), os.path.join(inc, "usr/local/lib/calamares/modules/everestos"))
    merge_tree(os.path.join(cal, "branding", "everestos"), os.path.join(inc, "etc/calamares/branding/everestos"))

    # 4) desktop files (autostart, lightdm, lock screen saver, plymouth script, services ...)
    merge_tree(os.path.join(ROOT, "desktop"), inc)

    # 5) default user configuration = Mega Edition, teal accent (the live session uses it;
    #    the installer rewrites it with the user's own choices)
    st = SetupState(fullname="Live", username="live", password="live00")
    for rel, text in theme.render_user_config(st, exists=None).items():
        put("etc/skel/" + rel, text, inc=inc)

    # 6) build variables for the hooks
    shutil.copy2(os.path.join(ROOT, "config.env"), os.path.join(inc, "usr/share/everestos/build.env"))

    for rel in EXECUTABLE:
        p = os.path.join(inc, rel)
        if os.path.exists(p):
            os.chmod(p, 0o755)
    print("staged", sum(len(f) for _, _, f in os.walk(inc)), "files into", inc)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
