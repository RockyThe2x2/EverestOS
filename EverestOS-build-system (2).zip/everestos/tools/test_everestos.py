#!/usr/bin/env python3
"""Offline tests for everything that can be tested without GTK, Calamares or an ISO build.
Run:  python3 tools/test_everestos.py -v
"""
import ast
import glob
import json
import os
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "installer"))

import yaml  # noqa: E402
from lxml import etree  # noqa: E402

from everestos import apply, catalog, i18n, layout, searchcore, slideshow, theme  # noqa: E402
from everestos.state import SetupState, suggest_username  # noqa: E402


def good_state(**kw):
    st = SetupState(fullname="Ada Lovelace", username="ada", hostname="ada-pc", password="s3cret!", **kw)
    return st


class TranslationTests(unittest.TestCase):
    def test_every_key_has_every_language(self):
        for key, entry in i18n.table().items():
            for short in catalog.SHORT_CODES:
                self.assertTrue(entry.get(short), "%s missing for %s" % (key, short))

    def test_placeholders_match_english(self):
        ph = re.compile(r"\{(\w+)\}")
        for key, entry in i18n.table().items():
            want = set(ph.findall(entry["en"]))
            for short, text in entry.items():
                self.assertEqual(want, set(ph.findall(text)), "%s/%s placeholders" % (key, short))

    def test_wizard_uses_only_existing_keys(self):
        used = set()
        for fname in ("wizard.py", "search_ui.py", "slideshow.py"):
            tree = ast.parse(open(os.path.join(ROOT, "installer/everestos", fname), encoding="utf-8").read())
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, (ast.Attribute, ast.Name)):
                    name = node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id
                    if name == "t" and node.args and isinstance(node.args[0], ast.Constant):
                        used.add(node.args[0].value)
        used |= {"cat_" + c for c in catalog.MENU_CATEGORIES} | {a.desc for a in catalog.APPS if a.desc}
        used |= {e.desc_key for e in catalog.EDITIONS.values()}
        used |= {"err_name", "err_username", "err_hostname", "err_password"}
        self.assertFalse(used - set(i18n.table()), "undefined keys: %s" % (used - set(i18n.table())))

    def test_translator_formats_and_falls_back(self):
        t = i18n.Translator("ru_RU")
        self.assertEqual(t("step_of", n=2, total=5), "Шаг 2 из 5")
        self.assertEqual(i18n.Translator("xx_XX")("next"), "Next")
        self.assertEqual(t("no_such_key"), "no_such_key")

    def test_po_export(self):
        with tempfile.TemporaryDirectory() as d:
            i18n.export_po(d)
            self.assertEqual(len(glob.glob(d + "/*.po")), len(catalog.LANGUAGES))
            self.assertIn("Выберите редакцию", open(d + "/ru.po", encoding="utf-8").read())


class StateTests(unittest.TestCase):
    def test_valid_state(self):
        self.assertEqual(good_state().validate(), [])

    def test_rejects_bad_input(self):
        for field, value, err in (("username", "Root", "err_username"), ("username", "root", "err_username"),
                                  ("username", "1abc", "err_username"), ("hostname", "-bad", "err_hostname"),
                                  ("hostname", "has space", "err_hostname"), ("password", "123", "err_password"),
                                  ("fullname", "  ", "err_name"), ("accent", "teal", "bad_accent"),
                                  ("timezone", "../etc", "bad_timezone")):
            st = good_state()
            setattr(st, field, value)
            self.assertIn(err, st.validate(), (field, value))

    def test_password_mismatch(self):
        self.assertIn("err_password", good_state().validate_name_page("other"))

    def test_json_roundtrip_and_mode(self):
        st = good_state()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "s.json")
            st.save(p)
            self.assertEqual(oct(os.stat(p).st_mode & 0o777), "0o600")
            self.assertEqual(SetupState.load(p), st)
        self.assertNotIn("password", json.loads(st.to_json_public()))

    def test_edition_switch_drops_mega_apps(self):
        st = good_state()
        st.menu_pinned = ["browser", "office", "store"]
        st.set_edition("original")
        self.assertEqual(st.menu_pinned, ["browser"])

    def test_suggest_username(self):
        self.assertEqual(suggest_username("John Smith"), "john")
        self.assertEqual(suggest_username("Иван Петров"), "")


class ThemeTests(unittest.TestCase):
    def files(self, **kw):
        return theme.render_user_config(good_state(**kw))

    def test_all_xml_parses(self):
        for ed in ("mega", "original"):
            st = good_state()
            st.set_edition(ed)
            for path, text in theme.render_user_config(st).items():
                if path.endswith(".xml"):
                    etree.fromstring(text.encode())

    def test_search_icon_only_in_mega(self):
        mega = good_state()
        orig = good_state()
        orig.set_edition("original")
        fm, fo = theme.render_user_config(mega), theme.render_user_config(orig)
        self.assertTrue(any("everest-search" in k for k in fm))
        self.assertFalse(any("everest-search" in k for k in fo))
        pm = fm[".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"]
        po = fo[".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"]
        self.assertIn('value="everest-search.desktop"', pm)
        self.assertNotIn("everest-search", po)

    def test_three_segments_on_left_edge(self):
        xml = etree.fromstring(self.files()[".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"].encode())
        panels = [p for p in xml.iter("property") if (p.get("name") or "").startswith("panel-")]
        self.assertEqual(len(panels), 3)
        for p in panels:
            vals = {c.get("name"): c.get("value") for c in p if c.get("name")}
            self.assertEqual(vals["mode"], "1")  # vertical
            self.assertTrue(vals["position"].startswith("p=0;x="))

    def test_accent_reaches_css_and_menu_style(self):
        st = good_state(accent="#EC4899")
        f = theme.render_user_config(st)
        self.assertIn("#EC4899", f[".config/gtk-3.0/gtk.css"])
        st.menu_style = "grid"
        self.assertIn("view-as-icons=true", theme.render_whisker_rc(st))
        st.menu_style = "list"
        self.assertIn("view-as-icons=false", theme.render_whisker_rc(st))

    def test_hidden_categories(self):
        st = good_state()
        self.assertIsNone(theme.render_menu_file(st))
        st.menu_categories = [c for c in catalog.MENU_CATEGORIES if c not in ("Games", "Office")]
        menu = theme.render_menu_file(st)
        self.assertIn("<Name>Games</Name>", menu)
        self.assertIn("<Name>Office</Name>", menu)
        self.assertNotIn("<Name>Internet</Name>", menu)

    def test_pinned_resolution(self):
        st = good_state()
        st.menu_pinned = ["editor", "calc"]
        rc = theme.render_whisker_rc(st, exists=lambda i: i == "mousepad.desktop" or i == "galculator.desktop")
        self.assertIn("favorites=mousepad.desktop,galculator.desktop", rc)

    def test_ime_files_only_for_cjk(self):
        self.assertNotIn(".xsessionrc", theme.render_user_config(good_state()))
        ko = good_state(language="ko_KR")
        f = theme.render_user_config(ko)
        self.assertIn("fcitx", f[".xsessionrc"])
        self.assertIn("hangul", f[".config/fcitx5/profile"])

    def test_lock_screen_wiring(self):
        f = self.files()
        ss = f[".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-screensaver.xml"]
        self.assertIn(theme.SAVER_THEME_ID, ss)
        self.assertIn("xfce4-screensaver-command --lock", f[".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml"])
        desktop = open(os.path.join(ROOT, "desktop/usr/share/applications/screensavers/everestos-clock.desktop")).read()
        self.assertIn("Categories=Screensaver;", desktop)
        self.assertEqual("screensavers-" + "everestos-clock.desktop", theme.SAVER_THEME_ID)

    def test_wallpaper_is_the_mountain_photo(self):
        self.assertTrue(theme.WALLPAPER.endswith("wallpaper.jpg"))
        self.assertIn(theme.WALLPAPER, self.files()[".config/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml"])

    def test_geometry_never_overlaps(self):
        for w, h in ((800, 600), (1024, 768), (1280, 720), (1366, 768), (1920, 1080), (2560, 1440), (3840, 2160)):
            for search in (True, False):
                g = theme.compute_geometry(w, h, search)
                top_end = g[1]["y"] + (2 if search else 1) * theme.PANEL_SIZE
                mid_end = g[2]["y"] + g[2]["length"] * h / 100
                self.assertLessEqual(top_end, g[2]["y"], (w, h, search))
                self.assertLessEqual(mid_end, g[3]["y"], (w, h, search))
                self.assertLess(g[3]["y"] + 2 * theme.PANEL_SIZE, h)

    def test_colour_helpers(self):
        self.assertEqual(theme.shade("#FFFFFF", 0.5), "#808080")
        self.assertEqual(theme.contrast_text("#FFFF00"), "#0B0B0B")
        self.assertEqual(theme.contrast_text("#000080"), "#FFFFFF")


class FakeRunner(apply.Runner):
    PACKAGES = ["bash", "firefox-esr", "calamares", "live-boot", "live-config", "libreoffice-writer",
                "libreoffice-core", "gimp", "vlc", "vlc-plugin-base", "flatpak", "catfish", "mousepad"]

    def __init__(self, root):
        super().__init__(root)
        self.calls, self.inputs = [], []

    def chroot(self, args, input_text=None, check=True):
        self.calls.append(list(args))
        self.inputs.append(input_text)

        class R:
            returncode = 0
            stdout = "\n".join(FakeRunner.PACKAGES) if args[0] == "dpkg-query" else ""
            stderr = ""
        return R()


def make_root(tmp):
    for d in ("etc/skel/.config/xfce4/panel/launcher-2", "usr/share/zoneinfo/Asia", "usr/share/applications",
              "etc/xdg/autostart", "usr/lib/everestos", "etc/sudoers.d", "var/lib/everestos", "etc/skel/Desktop"):
        os.makedirs(os.path.join(tmp, d), exist_ok=True)
    open(tmp + "/usr/share/zoneinfo/Asia/Almaty", "w").close()
    open(tmp + "/etc/group", "w").write("root:x:0:\nsudo:x:27:\naudio:x:29:\nvideo:x:44:\nnetdev:x:108:\n")
    open(tmp + "/etc/skel/.config/xfce4/panel/launcher-2/leftover.desktop", "w").write("old")
    for rel in apply.INSTALLER_LEFTOVERS:
        p = os.path.join(tmp, rel)
        if not os.path.exists(p):
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w").write("x")
    open(tmp + "/usr/share/applications/mousepad.desktop", "w").close()


class ApplyTests(unittest.TestCase):
    def run_apply(self, **kw):
        tmp = tempfile.mkdtemp()
        make_root(tmp)
        st = good_state(**kw)
        st.language, st.timezone = "kk_KZ", "Asia/Almaty"
        st.keyboard_layout, st.keyboard_options = "kz,us", "grp:alt_shift_toggle"
        return tmp, st

    def test_mega_install(self):
        tmp, st = self.run_apply()
        r = FakeRunner(tmp)
        steps = []
        apply.apply_all(tmp, st, r, progress=lambda f, m: steps.append((f, m)), log=lambda *_: None)
        rd = lambda p: open(os.path.join(tmp, p), encoding="utf-8").read()
        self.assertIn("LANG=kk_KZ.UTF-8", rd("etc/default/locale"))
        self.assertEqual(rd("etc/timezone").strip(), "Asia/Almaty")
        self.assertEqual(os.readlink(tmp + "/etc/localtime"), "/usr/share/zoneinfo/Asia/Almaty")
        self.assertIn('XKBLAYOUT="kz,us"', rd("etc/default/keyboard"))
        self.assertEqual(rd("etc/hostname").strip(), "ada-pc")
        self.assertEqual(rd("etc/everestos/edition").strip(), "mega")
        self.assertIn("everest-search.desktop", rd("etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"))
        self.assertFalse(os.path.exists(tmp + "/etc/skel/.config/xfce4/panel/launcher-2/leftover.desktop"))
        useradd = next(c for c in r.calls if c[0] == "useradd")
        self.assertIn("ada", useradd)
        self.assertIn("sudo,audio,video,netdev", useradd)  # only groups that exist
        # no Mega purge, live bits removed
        self.assertFalse(any(c[:3] == ["apt-get", "-y", "purge"] and "gimp" in c for c in r.calls))
        purge = next(c for c in r.calls if c[:3] == ["apt-get", "-y", "purge"])
        self.assertEqual(sorted(purge[3:]), ["calamares", "live-boot", "live-config"])
        for rel in apply.INSTALLER_LEFTOVERS:
            self.assertFalse(os.path.exists(os.path.join(tmp, rel)), rel)
        self.assertEqual(steps[-1], (1.0, "Done"))

    def test_original_purges_mega_apps_and_has_no_search(self):
        tmp, st = self.run_apply()
        st.set_edition("original")
        r = FakeRunner(tmp)
        apply.apply_all(tmp, st, r, log=lambda *_: None)
        purges = [c for c in r.calls if c[:3] == ["apt-get", "-y", "purge"]]
        victims = set(purges[0][3:])
        self.assertTrue({"libreoffice-writer", "libreoffice-core", "gimp", "vlc", "vlc-plugin-base", "flatpak", "catfish"} <= victims)
        self.assertNotIn("firefox-esr", victims)
        self.assertNotIn("mousepad", victims)
        panel = open(tmp + "/etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml").read()
        self.assertNotIn("everest-search", panel)
        self.assertEqual(open(tmp + "/etc/everestos/edition").read().strip(), "original")

    def test_password_only_via_stdin(self):
        tmp, st = self.run_apply()
        r = FakeRunner(tmp)
        apply.apply_all(tmp, st, r, log=lambda *_: None)
        self.assertFalse(any(st.password in " ".join(c) for c in r.calls))
        self.assertIn("ada:s3cret!\n", r.inputs)

    def test_invalid_state_is_refused(self):
        tmp, st = self.run_apply()
        st.username = "root"
        with self.assertRaises(ValueError):
            apply.apply_all(tmp, st, FakeRunner(tmp))

    def test_unknown_timezone_falls_back_to_utc(self):
        tmp, st = self.run_apply()
        st.timezone = "Mars/Olympus"
        apply.set_timezone(tmp, st)
        self.assertEqual(open(tmp + "/etc/timezone").read().strip(), "UTC")


class MiscTests(unittest.TestCase):
    def test_slideshow(self):
        for ed in ("mega", "original"):
            q = slideshow.render_show_qml("ja_JP", ed, "#3B82F6", icon_lookup=lambda n: "/x/%s.svg" % n)
            self.assertEqual(q.count("{"), q.count("}"))
            self.assertEqual(q.count("    Slide {"), 1 + len(catalog.GALLERY[ed]))
            self.assertIn("#3B82F6", q)
        self.assertIn("インストール中", slideshow.render_show_qml("ja_JP"))
        self.assertEqual(slideshow.q('a"b\\c'), 'a\\"b\\\\c')
        self.assertEqual(slideshow.retint("x #2ABAA3 y", "#EF4444"), "x #EF4444 y")

    def test_gallery_apps_exist_in_their_edition(self):
        for ed, keys in catalog.GALLERY.items():
            allowed = {a.key for a in catalog.apps_for(ed)}
            self.assertTrue(set(keys) <= allowed, ed)

    def test_mega_only_patterns_never_match_original_apps(self):
        import fnmatch
        for app_pkg in ("firefox-esr", "mousepad", "xfce4-terminal", "ristretto", "galculator", "mpv", "thunar",
                        "xfce4-panel", "network-manager", "lightdm", "python3-gi", "fcitx5", "xfce4-screensaver"):
            for pat in catalog.MEGA_ONLY_PACKAGES:
                self.assertFalse(fnmatch.fnmatchcase(app_pkg, pat), (app_pkg, pat))

    def test_search_core(self):
        apps = [("Firefox", "Web Browser", 1), ("Files", "File manager", 2), ("Calc", "finance tool", 3)]
        # prefix matches first (alphabetical), then a match only found in the description
        self.assertEqual([n for n, _ in searchcore.match_apps("fi", apps)], ["Files", "Firefox", "Calc"])
        self.assertEqual(searchcore.match_apps("", apps), [])
        self.assertTrue(searchcore.web_url("a b&c").endswith("a+b%26c"))
        with tempfile.TemporaryDirectory() as home:
            open(os.path.join(home, "Report 2026.txt"), "w").close()
            os.makedirs(os.path.join(home, ".hidden"))
            open(os.path.join(home, ".hidden", "report.txt"), "w").close()
            hits = searchcore.find_files("report", home=home, runner=object())
            self.assertEqual([os.path.basename(h) for h in hits], ["Report 2026.txt"])

    def test_logo_svg_matches_source_png(self):
        from PIL import Image, ImageChops, ImageDraw
        src = Image.open(os.path.join(ROOT, "assets/logo-source.png")).convert("RGBA")
        im = Image.new("L", src.size, 0)
        d = ImageDraw.Draw(im)
        svg = open(os.path.join(ROOT, "assets/logo.svg")).read()
        rect = re.search(r'<rect x="(\d+)" y="(\d+)" width="(\d+)" height="(\d+)"', svg)
        x, y, w, h = map(int, rect.groups())
        d.rectangle([x, y, x + w - 1, y + h - 1], fill=255)
        d.rectangle([12, 169, 196, 1066], fill=255)
        d.rectangle([12, 891, 906, 1066], fill=255)
        a = src.getchannel("A").point(lambda v: 255 if v > 127 else 0)
        diff = sum(1 for v in ImageChops.difference(a, im).tobytes() if v)
        self.assertLessEqual(diff, 4)

    def test_every_yaml_config_parses(self):
        for f in glob.glob(ROOT + "/calamares/**/*.conf", recursive=True) + glob.glob(ROOT + "/calamares/**/*.desc", recursive=True):
            yaml.safe_load(open(f))
        s = yaml.safe_load(open(ROOT + "/calamares/settings.conf"))
        exec_modules = s["sequence"][1]["exec"]
        for m in ("partition", "mount", "unpackfs", "fstab", "everestos", "bootloader", "umount"):
            self.assertIn(m, exec_modules)
        self.assertLess(exec_modules.index("unpackfs"), exec_modules.index("everestos"))
        self.assertLess(exec_modules.index("everestos"), exec_modules.index("bootloader"))

    def test_python_files_compile_and_avoid_removed_modules(self):
        pyfiles = glob.glob(ROOT + "/**/*.py", recursive=True) + [ROOT + "/installer/launch-installer"]
        pyfiles += [f for f in glob.glob(ROOT + "/installer/bin/*") if "python" in open(f).readline()]
        for f in pyfiles:
            src = open(f, encoding="utf-8").read()
            compile(src, f, "exec")
            self.assertNotRegex(src, r"^\s*import crypt\b", f)  # removed in Python 3.13 (Debian 13)

    def test_shell_scripts_parse(self):
        files = [ROOT + "/build.sh", ROOT + "/installer/bin/everestos-guest-additions", ROOT + "/desktop/usr/lib/everestos/lockclock"]
        files += glob.glob(ROOT + "/live-build/auto/*") + glob.glob(ROOT + "/live-build/config/hooks/live/*") + glob.glob(ROOT + "/tools/*.sh")
        for f in files:
            shebang = open(f).readline()
            sh = "bash" if "bash" in shebang else "sh"
            r = subprocess.run([sh, "-n", f], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, "%s: %s" % (f, r.stderr))

    def test_package_lists_are_clean(self):
        seen = {}
        for f in glob.glob(ROOT + "/live-build/config/package-lists/*.list.chroot"):
            for line in open(f):
                line = line.split("#")[0].strip()
                if line:
                    self.assertRegex(line, r"^[a-z0-9][a-z0-9+.-]*$", (f, line))
                    seen.setdefault(line, []).append(os.path.basename(f))
        dups = {k: v for k, v in seen.items() if len(v) > 1}
        self.assertFalse(dups, dups)
        self.assertNotIn("locales", seen)  # conflicts with locales-all
        self.assertIn("xfce4-screensaver", seen)
        self.assertIn("calamares", seen)
        # every package the Original edition must keep is NOT in the mega list
        mega = [l.strip() for l in open(ROOT + "/live-build/config/package-lists/mega.list.chroot") if l.strip() and not l.startswith("#")]
        for p in ("firefox-esr", "mousepad", "xfce4-terminal", "ristretto", "galculator", "mpv"):
            self.assertNotIn(p, mega)

    def test_github_workflow(self):
        wf = yaml.safe_load(open(ROOT + "/.github/workflows/build-iso.yml"))
        steps = wf["jobs"]["build"]["steps"]
        self.assertTrue(any("build.sh" in str(s.get("run", "")) for s in steps))
        self.assertTrue(any(s.get("with", {}).get("name") == "EverestOS-iso" for s in steps))

    def test_layout_screen_size_parser(self):
        class P:
            stdout = "Screen 0: minimum 16 x 16, current 1280 x 800, maximum 32767 x 32767\n"
        orig = layout.subprocess.run
        layout.subprocess.run = lambda *a, **k: P()
        try:
            self.assertEqual(layout.screen_size(), (1280, 800))
        finally:
            layout.subprocess.run = orig


if __name__ == "__main__":
    unittest.main()
