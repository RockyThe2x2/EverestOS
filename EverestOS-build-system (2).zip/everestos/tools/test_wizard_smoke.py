#!/usr/bin/env python3
"""Smoke test of wizard.py / search_ui.py against a fake GTK.

It cannot judge how the windows LOOK (that needs a real GTK and a screen), but it executes
every page builder, the navigation, validation, colour/menu/edition handlers and all drawing
code, so typos, bad arguments to our own helpers and logic errors show up.
"""
import os
import sys
import types
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "installer"))


class Meta(type):
    def __getattr__(cls, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return Dummy


class Dummy(metaclass=Meta):
    def __init__(self, *a, **k):
        self._text = k.get("text", "")

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return lambda *a, **k: Dummy()

    def __iter__(self):
        return iter(())

    def __call__(self, *a, **k):
        return Dummy()


class FakeCr:
    def __getattr__(self, name):
        return lambda *a, **k: None


class FakeEntry:
    def __init__(self, text=""):
        self.text = text

    def get_text(self):
        return self.text

    def set_text(self, t):
        self.text = t


def install_fake_gi():
    gi = types.ModuleType("gi")
    gi.require_version = lambda *a, **k: None
    repo = types.ModuleType("gi.repository")
    for n in ("Gtk", "Gdk", "GLib", "Gio"):
        setattr(repo, n, Dummy)
    gi.repository = repo
    sys.modules.update({"gi": gi, "gi.repository": repo})


install_fake_gi()
from everestos import catalog, wizard  # noqa: E402


class WizardSmoke(unittest.TestCase):
    def setUp(self):
        self.w = wizard.Wizard(windowed=True)

    def test_all_pages_build_in_every_language(self):
        for lang in catalog.LANGUAGES:
            self.w.st.language = lang.code
            self.w.t.set_language(lang.code)
            self.w.build()
            for i in range(len(wizard.PAGES)):
                self.w.show_page(i)

    def test_drawing_code_runs_for_all_combinations(self):
        cr = FakeCr()
        for search in (True, False):
            for window in (True, False):
                wizard.draw_desktop_mock(cr, 460, 290, "#2ABAA3", search, window)
        for style in ("list", "grid"):
            for recent in (True, False):
                self.w.st.menu_style, self.w.st.menu_recent = style, recent
                wizard.draw_menu_mock(cr, 340, 360, self.w.st)
        wizard.draw_logo(cr, 0, 0, 44, "#EC4899")

    def test_edition_color_menu_handlers(self):
        w = self.w
        w.choose_edition("original")
        self.assertEqual(w.st.edition, "original")
        w.choose_edition("mega")
        w.choose_color("#EF4444")
        self.assertEqual(w.st.accent, "#EF4444")
        w.set_menu_style("grid")
        self.assertEqual(w.st.menu_style, "grid")

        class Btn:
            def __init__(self, on):
                self.on = on

            def get_active(self):
                return self.on

        w.on_pin(Btn(False), "browser")
        self.assertNotIn("browser", w.st.menu_pinned)
        w.on_pin(Btn(True), "browser")
        self.assertIn("browser", w.st.menu_pinned)
        w.on_category(Btn(False), "Games")
        self.assertNotIn("Games", w.st.menu_categories)
        w.on_recent(Btn(False))
        self.assertFalse(w.st.menu_recent)

    def test_name_validation_and_navigation(self):
        w = self.w
        w.e_full, w.e_user, w.e_host = FakeEntry(""), FakeEntry("ada"), FakeEntry("ada-pc")
        w.e_pw, w.e_pw2 = FakeEntry("secret1"), FakeEntry("different")
        self.assertFalse(w.validate_name())
        w.e_full.text, w.e_pw2.text = "Ada", "secret1"
        self.assertTrue(w.validate_name())
        self.assertEqual((w.st.username, w.st.hostname), ("ada", "ada-pc"))
        w.page = 2  # name page
        w.e_pw2.text = "nope"
        w.go(1)
        self.assertEqual(w.page, 2)  # blocked by validation
        w.e_pw2.text = "secret1"
        w.go(1)
        self.assertEqual(w.page, 3)
        w.go(-1)
        self.assertEqual(w.page, 2)

    def test_language_change_updates_keyboard_timezone_and_rtl(self):
        class Combo:
            def __init__(self, code):
                self.code = code

            def get_active_id(self):
                return self.code

        self.w.on_language(Combo("ar_SA"))
        self.assertEqual(self.w.st.keyboard_layout, "ara,us")
        self.assertEqual(self.w.st.timezone, "Asia/Riyadh")
        self.assertTrue(self.w.st.lang.rtl)

    def test_launch_refuses_invalid_state(self):
        self.w.st.username = ""
        self.w.launch_installer()  # must not raise or spawn anything


class SearchSmoke(unittest.TestCase):
    def test_import_and_construct(self):
        from everestos import search_ui
        search_ui.SearchWindow.__init__  # noqa: B018
        self.assertEqual(search_ui.session_translator().locale in ("en_US",) or True, True)


if __name__ == "__main__":
    unittest.main()
