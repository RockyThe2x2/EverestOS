#!/usr/bin/env bash
# EverestOS ISO builder.  Run on a Debian 12/13 or Ubuntu 22.04+ machine (a VM is fine).
#
#   ./build.sh            install dependencies, stage files, build the ISO
#   ./build.sh stage      only assemble the file tree (no root needed, quick check)
#   ./build.sh verify     check the finished ISO
#   ./build.sh clean      remove build/ (keeps the downloaded package cache)
#
# Needs: ~25 GB free disk, 4 GB RAM, internet.  Takes 20-60 minutes the first time.
# Do not build on NTFS / a VirtualBox shared folder (live-build needs a real Linux filesystem).
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
# shellcheck disable=SC1091
source config.env

BUILD_DIR="${BUILD_DIR:-$PWD/build/lb}"
OUT_DIR="${OUT_DIR:-$PWD/output}"
cmd="${1:-all}"

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
die()  { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

need_root() { [ "$(id -u)" -eq 0 ] || exec sudo -E BUILD_DIR="$BUILD_DIR" OUT_DIR="$OUT_DIR" "$0" "$@"; }

install_deps() {
    say "Installing build dependencies"
    command -v apt-get >/dev/null || die "This script needs a Debian/Ubuntu build machine (apt-get not found)."
    apt-get update
    apt-get install -y live-build debootstrap squashfs-tools xorriso mtools dosfstools \
        grub-pc-bin grub-efi-amd64-bin isolinux syslinux syslinux-utils syslinux-common \
        debian-archive-keyring python3 python3-pil python3-yaml rsync zstd
    # Older Ubuntu hosts do not know newer Debian releases: point them at the generic script.
    if [ ! -e "/usr/share/debootstrap/scripts/${DEBIAN_RELEASE}" ]; then
        ln -s sid "/usr/share/debootstrap/scripts/${DEBIAN_RELEASE}"
        echo "created debootstrap script link for ${DEBIAN_RELEASE}"
    fi
}

preflight() {
    say "Pre-flight checks"
    local avail_gb
    avail_gb=$(df -BG --output=avail "$(dirname "$BUILD_DIR")" 2>/dev/null | tail -n1 | tr -dc '0-9' || echo 0)
    [ "${avail_gb:-0}" -ge 20 ] || echo "WARNING: only ${avail_gb:-?} GB free where the build runs; 25 GB recommended."
    case "$(df -T "$(dirname "$BUILD_DIR")" | tail -n1 | awk '{print $2}')" in
        ntfs*|vboxsf|fuseblk|exfat|vfat) die "Build directory is on an unsupported filesystem; use ext4/xfs/btrfs." ;;
    esac
    [ "$(uname -m)" = "x86_64" ] || die "Build machine must be x86_64 (the ISO is amd64)."
}

stage() {
    say "Staging files"
    mkdir -p "$BUILD_DIR"
    # Refresh our config; keep cache/ (downloaded packages) from earlier builds.
    rm -rf "$BUILD_DIR/auto" "$BUILD_DIR/config" "$BUILD_DIR/everestos.env"
    cp -a live-build/auto live-build/config "$BUILD_DIR/"
    cp config.env "$BUILD_DIR/everestos.env"
    # Uploads/zip files often lose the executable bit; live-build needs these runnable.
    chmod 755 "$BUILD_DIR"/auto/* "$BUILD_DIR"/config/hooks/live/*
    python3 tools/stage.py "$BUILD_DIR"
}

build_iso() {
    say "Running live-build (this is the long step)"
    # start from a clean chroot/binary state (the package cache is kept)
    ( cd "$BUILD_DIR" && { lb clean noauto >/dev/null 2>&1 || true; } && ./auto/config && ./auto/build )
    local iso
    iso=$(ls -1 "$BUILD_DIR"/*.iso 2>/dev/null | head -n1 || true)
    [ -n "$iso" ] || die "live-build finished but produced no ISO. See $BUILD_DIR/build.log"
    mkdir -p "$OUT_DIR"
    cp "$iso" "$OUT_DIR/$ISO_FILENAME"
    ( cd "$OUT_DIR" && sha256sum "$ISO_FILENAME" > "$ISO_FILENAME.sha256" )
    [ -n "${SUDO_USER:-}" ] && chown -R "$SUDO_USER": "$OUT_DIR" || true
    say "Done: $OUT_DIR/$ISO_FILENAME"
    ls -lh "$OUT_DIR/$ISO_FILENAME"
}

verify() {
    local iso="$OUT_DIR/$ISO_FILENAME"
    [ -f "$iso" ] || die "No ISO at $iso (run ./build.sh first)"
    say "Checksum";  ( cd "$OUT_DIR" && sha256sum -c "$ISO_FILENAME.sha256" )
    say "Boot records (expect both a BIOS and an EFI entry)"
    xorriso -indev "$iso" -report_el_torito plain 2>&1 | grep -Ei 'El Torito|BIOS|UEFI|platform' || true
    xorriso -indev "$iso" -report_system_area plain 2>&1 | grep -Ei 'MBR|GPT|hybrid' || true
    say "Key files"
    for f in /live/filesystem.squashfs /live/vmlinuz* /EFI/boot/bootx64.efi /boot/grub/grub.cfg /isolinux/isolinux.bin; do
        if xorriso -indev "$iso" -find "$f" -exec lsdl 2>/dev/null | grep -q .; then echo "  found $f"; else echo "  MISSING $f"; fi
    done
}

case "$cmd" in
    stage)  stage ;;
    verify) verify ;;
    clean)  need_root "$@"; rm -rf "$PWD/build"; echo "removed build/" ;;
    all)    need_root "$@"; install_deps; preflight; stage; build_iso; verify ;;
    *)      sed -n '2,12p' "$0"; exit 1 ;;
esac
