#!/usr/bin/env python3
# EverestOS Calamares job: applies edition, language, keyboard, time zone, host name, user account,
# colour and start-menu choices (read from /var/lib/everestos/setup.json) to the target system.
import os
import sys

import libcalamares

sys.path.insert(0, "/usr/share/everestos")

STATE = "/var/lib/everestos/setup.json"
DONE_FLAG = "/run/everestos-installed"


def pretty_name():
    return "Applying your EverestOS settings"


def run():
    from everestos import apply
    from everestos.state import SetupState

    root = libcalamares.globalstorage.value("rootMountPoint")
    if not root:
        return ("Missing root mount point", "The partitioning step did not provide rootMountPoint.")
    if not os.path.exists(STATE):
        return ("EverestOS settings not found",
                "Start the installer from the EverestOS setup wizard (Install EverestOS icon).")

    state = SetupState.load(STATE)

    def progress(fraction, message):
        libcalamares.job.setprogress(fraction)
        libcalamares.utils.debug("everestos: %s" % message)

    try:
        apply.apply_all(root, state, apply.Runner(root), progress, libcalamares.utils.debug)
    except Exception as exc:  # report to the Calamares UI instead of a bare traceback
        return ("EverestOS settings could not be applied", str(exc))

    # The password must not linger in the live session.
    try:
        os.remove(STATE)
    except OSError:
        pass
    open(DONE_FLAG, "w").close()  # tells the wizard the install really finished
    return None
