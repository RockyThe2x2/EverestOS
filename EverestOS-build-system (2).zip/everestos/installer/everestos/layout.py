"""Session helper (autostart): fit the floating taskbar segments to the real screen size,
set the wallpaper on every monitor once, and bind Super+L to the lock screen.

Floating XFCE panels are positioned in pixels, but a VirtualBox screen changes size after the
guest tools resize it -- so we recompute positions when the resolution changes.
"""
import os
import re
import subprocess
import sys
import time

from . import theme

FLAG = os.path.expanduser("~/.config/everestos/first-run-done")


def screen_size():
    """(w, h) of the whole X screen via xrandr, or None."""
    try:
        out = subprocess.run(["xrandr", "--current"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.search(r"current (\d+) x (\d+)", out)
    return (int(m.group(1)), int(m.group(2))) if m else None


def _xfconf(*args):
    try:
        subprocess.run(["xfconf-query", "-c", "xfce4-panel"] + list(args), capture_output=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        pass


def apply_geometry(w, h, search):
    for pid, g in theme.compute_geometry(w, h, search).items():
        base = "/panels/panel-%d/" % pid
        _xfconf("-p", base + "position", "-s", "p=0;x=%d;y=%d" % (g["x"], g["y"]))
        _xfconf("-p", base + "length", "-s", str(g["length"]))


def read_search_flag():
    """Does the installed edition have the search icon?"""
    try:
        with open("/etc/everestos/edition") as fh:
            return fh.read().strip() != "original"
    except OSError:
        return True  # live session shows the Mega layout


def first_run():
    if os.path.exists(FLAG):
        return
    # wallpaper on every monitor name xfdesktop knows about
    try:
        props = subprocess.run(["xfconf-query", "-c", "xfce4-desktop", "-l"], capture_output=True,
                               text=True, timeout=5).stdout.split()
        for p in props:
            if p.endswith("/last-image"):
                subprocess.run(["xfconf-query", "-c", "xfce4-desktop", "-p", p, "-s", theme.WALLPAPER],
                               capture_output=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        pass
    # Super+L locks the screen (Ctrl+Alt+L is already a default binding)
    try:
        subprocess.run(["xfconf-query", "-c", "xfce4-keyboard-shortcuts", "-n", "-t", "string",
                        "-p", "/commands/custom/<Super>l", "-s", "xflock4"], capture_output=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        pass
    os.makedirs(os.path.dirname(FLAG), exist_ok=True)
    open(FLAG, "w").close()


def main(argv):
    watch = "--watch" in argv
    time.sleep(2)  # let xfce4-panel come up first
    first_run()
    search = read_search_flag()
    last = None
    while True:
        size = screen_size()
        if size and size != last:
            apply_geometry(size[0], size[1], search)
            last = size
        if not watch:
            return 0
        time.sleep(3)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
