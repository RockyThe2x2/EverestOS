"""EverestOS setup wizard, installer glue and desktop theming."""
__version__ = "1.0"
