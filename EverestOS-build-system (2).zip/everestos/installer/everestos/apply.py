"""Apply a SetupState to a freshly unpacked target system.

Runs inside the Calamares job `everestos` (as root, in the live system) but has no Calamares
dependency, so it can be unit-tested with a temporary directory and a fake Runner.
"""
import fnmatch
import os
import subprocess

from . import catalog, theme

LIVE_PACKAGES = (
    "live-boot", "live-boot-initramfs-tools", "live-config", "live-config-systemd",
    "live-config-sysvinit", "calamares",
)
DEFAULT_GROUPS = ("sudo", "adm", "cdrom", "audio", "video", "plugdev", "netdev", "dip", "lpadmin", "scanner")
# Files that exist only to start the installer from the live session.
INSTALLER_LEFTOVERS = (
    "etc/xdg/autostart/everestos-setup.desktop",
    "usr/share/applications/everestos-install.desktop",
    "etc/skel/Desktop/everestos-install.desktop",
    "usr/lib/everestos/launch-installer",
    "etc/sudoers.d/everestos-installer",
    "usr/local/lib/calamares",
    "var/lib/everestos/setup.json",
)


class Runner:
    """Runs commands inside the target root with chroot(8)."""

    def __init__(self, root):
        self.root = root

    def chroot(self, args, input_text=None, check=True):
        env = dict(os.environ, DEBIAN_FRONTEND="noninteractive", LC_ALL="C")
        return subprocess.run(["chroot", self.root] + list(args), input=input_text, text=True,
                              capture_output=True, check=check, env=env)


# ------------------------------------------------------------------ file helpers
def _path(root, rel):
    return os.path.join(root, rel.lstrip("/"))


def write_file(root, rel, content, mode=0o644):
    path = _path(root, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    os.chmod(path, mode)


def remove_path(root, rel):
    path = _path(root, rel)
    if os.path.islink(path) or os.path.isfile(path):
        os.remove(path)
    elif os.path.isdir(path):
        import shutil
        shutil.rmtree(path, ignore_errors=True)


def _group_names(root):
    try:
        with open(_path(root, "etc/group"), encoding="utf-8") as fh:
            return {line.split(":")[0] for line in fh if ":" in line}
    except OSError:
        return set()


def installed_packages(runner):
    out = runner.chroot(["dpkg-query", "-W", "-f=${Package}\\n"], check=False).stdout or ""
    return [p for p in out.split() if p]


def matching(installed, patterns):
    return sorted({p for p in installed for pat in patterns if fnmatch.fnmatchcase(p, pat)})


# ------------------------------------------------------------------ steps
def set_locale(root, st):
    lang = st.lang
    text = "LANG=%s\n" % lang.utf8
    if lang.short != "en":
        text += "LANGUAGE=%s:en\n" % lang.short
    write_file(root, "etc/default/locale", text)


def set_timezone(root, st):
    tz = st.timezone
    if not os.path.exists(_path(root, "usr/share/zoneinfo/" + tz)):
        tz = "UTC"
    link = _path(root, "etc/localtime")
    if os.path.lexists(link):
        os.remove(link)
    os.makedirs(os.path.dirname(link), exist_ok=True)
    os.symlink("/usr/share/zoneinfo/" + tz, link)
    write_file(root, "etc/timezone", tz + "\n")


def set_keyboard(root, st):
    write_file(root, "etc/default/keyboard",
               'XKBMODEL="pc105"\nXKBLAYOUT="%s"\nXKBVARIANT=""\nXKBOPTIONS="%s"\nBACKSPACE="guess"\n'
               % (st.keyboard_layout, st.keyboard_options))


def set_hostname(root, st):
    write_file(root, "etc/hostname", st.hostname + "\n")
    write_file(root, "etc/hosts",
               "127.0.0.1\tlocalhost\n127.0.1.1\t%s\n::1\t\tlocalhost ip6-localhost ip6-loopback\n"
               "ff02::1\t\tip6-allnodes\nff02::2\t\tip6-allrouters\n" % st.hostname)


def write_skel(root, st, exists=None):
    """Render the user's desktop configuration into /etc/skel so `useradd -m` copies it."""
    remove_path(root, "etc/skel/.config/xfce4/panel")
    remove_path(root, "etc/skel/.config/menus")
    remove_path(root, "etc/skel/.config/fcitx5")
    remove_path(root, "etc/skel/.xsessionrc")
    for rel, content in theme.render_user_config(st, exists).items():
        write_file(root, "etc/skel/" + rel, content)


def create_user(root, st, runner):
    groups = [g for g in DEFAULT_GROUPS if g in _group_names(root)]
    cmd = ["useradd", "-m", "-s", "/bin/bash", "-c", st.fullname.strip()]
    if groups:
        cmd += ["-G", ",".join(groups)]
    cmd.append(st.username)
    runner.chroot(cmd)
    # Password goes through stdin only: never on a command line, never logged.
    runner.chroot(["chpasswd"], input_text="%s:%s\n" % (st.username, st.password))
    runner.chroot(["passwd", "-l", "root"], check=False)  # admin = sudo group


def apply_edition(root, st, runner, log=print):
    write_file(root, "etc/everestos/edition", st.edition + "\n")
    if st.edition_obj.search:
        return []
    victims = matching(installed_packages(runner), catalog.MEGA_ONLY_PACKAGES)
    if victims:
        log("Original edition: removing %d Mega-only packages" % len(victims))
        runner.chroot(["apt-get", "-y", "purge"] + victims)
        runner.chroot(["apt-get", "-y", "autoremove", "--purge"], check=False)
    return victims


def remove_live_bits(root, runner, log=print):
    pkgs = [p for p in installed_packages(runner) if p in LIVE_PACKAGES]
    if pkgs:
        log("Removing live-session packages: " + " ".join(pkgs))
        runner.chroot(["apt-get", "-y", "purge"] + pkgs, check=False)
    for rel in INSTALLER_LEFTOVERS:
        remove_path(root, rel)


def desktop_exists_in(root):
    base = _path(root, "usr/share/applications")
    return lambda desktop_id: os.path.exists(os.path.join(base, desktop_id))


# ------------------------------------------------------------------ driver
def apply_all(root, st, runner=None, progress=None, log=print):
    """Run every customisation step.  `progress(fraction, message)` is optional."""
    runner = runner or Runner(root)
    progress = progress or (lambda f, m: None)
    errors = st.validate()
    if errors:
        raise ValueError("invalid setup state: " + ", ".join(errors))

    steps = [
        ("Language",           lambda: set_locale(root, st)),
        ("Time zone",          lambda: set_timezone(root, st)),
        ("Keyboard",           lambda: set_keyboard(root, st)),
        ("Computer name",      lambda: set_hostname(root, st)),
        ("Edition",            lambda: apply_edition(root, st, runner, log)),
        ("Desktop appearance", lambda: write_skel(root, st, desktop_exists_in(root))),
        ("User account",       lambda: create_user(root, st, runner)),
        ("Cleaning up",        lambda: remove_live_bits(root, runner, log)),
        ("Boot image",         lambda: runner.chroot(["update-initramfs", "-u", "-k", "all"], check=False)),
    ]
    for i, (name, fn) in enumerate(steps):
        progress(i / len(steps), name)
        log("everestos: " + name)
        fn()
    progress(1.0, "Done")
