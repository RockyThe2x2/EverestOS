"""Static data: languages, editions, apps, colour palette and start-menu categories."""
from dataclasses import dataclass

VERSION = "1.0"
DEFAULT_ACCENT = "#2ABAA3"  # colour of the supplied logo

# ---------------------------------------------------------------- languages


@dataclass(frozen=True)
class Language:
    code: str            # glibc locale name without encoding, e.g. "ru_RU"
    native: str          # name written in the language itself
    english: str
    xkb_layout: str      # value for XKBLAYOUT in /etc/default/keyboard
    xkb_options: str     # value for XKBOPTIONS
    timezone: str        # sensible default, user can change it
    ime: str = ""        # fcitx5 engine: "", "hangul", "mozc", "pinyin"
    rtl: bool = False

    @property
    def short(self) -> str:
        return self.code.split("_")[0]

    @property
    def utf8(self) -> str:
        return self.code + ".UTF-8"


_TOGGLE = "grp:alt_shift_toggle"
LANGUAGES = (
    Language("en_US", "English", "English", "us", "", "UTC"),
    Language("ru_RU", "Русский", "Russian", "ru,us", _TOGGLE, "Europe/Moscow"),
    Language("bg_BG", "Български", "Bulgarian", "bg,us", _TOGGLE, "Europe/Sofia"),
    Language("fi_FI", "Suomi", "Finnish", "fi", "", "Europe/Helsinki"),
    Language("ko_KR", "한국어", "Korean", "kr", "", "Asia/Seoul", ime="hangul"),
    Language("ja_JP", "日本語", "Japanese", "jp", "", "Asia/Tokyo", ime="mozc"),
    Language("es_ES", "Español", "Spanish", "es", "", "Europe/Madrid"),
    Language("de_DE", "Deutsch", "German", "de", "", "Europe/Berlin"),
    Language("fr_FR", "Français", "French", "fr", "", "Europe/Paris"),
    Language("zh_CN", "简体中文", "Chinese (Simplified)", "cn", "", "Asia/Shanghai", ime="pinyin"),
    Language("pt_BR", "Português (Brasil)", "Portuguese (Brazil)", "br", "", "America/Sao_Paulo"),
    Language("tr_TR", "Türkçe", "Turkish", "tr", "", "Europe/Istanbul"),
    Language("ar_SA", "العربية", "Arabic", "ara,us", _TOGGLE, "Asia/Riyadh", rtl=True),
    Language("kk_KZ", "Қазақша", "Kazakh", "kz,us", _TOGGLE, "Asia/Almaty"),
    Language("uk_UA", "Українська", "Ukrainian", "ua,us", _TOGGLE, "Europe/Kyiv"),
)
LANG_BY_CODE = {l.code: l for l in LANGUAGES}
SHORT_CODES = tuple(l.short for l in LANGUAGES)

# (xkb layout, xkb options, label) -- every language default plus a few extras.
KEYBOARDS = tuple(
    [(l.xkb_layout, l.xkb_options, l.english + (" + US" if "," in l.xkb_layout else "")) for l in LANGUAGES]
    + [
        ("gb", "", "English (UK)"),
        ("ca", "", "Canadian"),
        ("it", "", "Italian"),
        ("pl", "", "Polish"),
        ("cz", "", "Czech"),
        ("se", "", "Swedish"),
        ("no", "", "Norwegian"),
        ("dk", "", "Danish"),
    ]
)

# ---------------------------------------------------------------- editions


@dataclass(frozen=True)
class Edition:
    key: str
    title: str          # product name; deliberately not translated
    desc_key: str
    search: bool        # search icon in the taskbar?


EDITIONS = {
    "mega": Edition("mega", "EverestOS Mega Edition", "edition_mega_desc", True),
    "original": Edition("original", "EverestOS Original and Fresh Edition", "edition_original_desc", False),
}

# Packages that exist only for the Mega Edition. When the user picks the Original and Fresh
# Edition they are purged from the freshly copied system (fnmatch patterns, matched against
# installed package names).
MEGA_ONLY_PACKAGES = (
    "libreoffice*", "gimp", "gimp-data", "vlc", "vlc-*", "libvlc*", "audacious", "audacious-*",
    "evince", "evince-common", "xfce4-screenshooter", "xfce4-taskmanager", "timeshift", "pitivi",
    "gnome-software", "gnome-software-*", "flatpak", "catfish",
)

# ---------------------------------------------------------------- apps


@dataclass(frozen=True)
class App:
    key: str
    name: str            # product name; not translated
    icon: str            # icon-theme name
    exec: str            # Exec= line for generated launchers
    ids: tuple           # candidate .desktop ids (first that exists wins)
    category: str        # start-menu category (XFCE menu name)
    mega_only: bool = False
    desc: str = ""       # strings.txt key used by the gallery


APPS = (
    App("browser", "Firefox", "firefox-esr", "firefox-esr %u", ("firefox-esr.desktop", "firefox.desktop"), "Internet", False, "app_browser"),
    App("files", "Files", "org.xfce.thunar", "thunar %U", ("thunar.desktop", "org.xfce.Thunar.desktop"), "Accessories", False, "app_files"),
    App("editor", "Text Editor", "org.xfce.mousepad", "mousepad %F", ("org.xfce.mousepad.desktop", "mousepad.desktop"), "Accessories", False, "app_editor"),
    App("terminal", "Terminal", "org.xfce.terminal", "xfce4-terminal", ("org.xfce.terminal.desktop", "xfce4-terminal.desktop"), "System", False, "app_terminal"),
    App("calc", "Calculator", "galculator", "galculator", ("galculator.desktop",), "Accessories", False, "app_calc"),
    App("viewer", "Image Viewer", "org.xfce.ristretto", "ristretto %f", ("org.xfce.ristretto.desktop", "ristretto.desktop"), "Graphics", False, "app_viewer"),
    App("media", "Media Player", "mpv", "mpv --player-operation-mode=pseudo-gui -- %U", ("mpv.desktop",), "Multimedia", False, "app_media"),
    App("settings", "Settings", "org.xfce.settings.manager", "xfce4-settings-manager", ("xfce-settings-manager.desktop", "org.xfce.settings.manager.desktop"), "Settings", False, ""),
    # ---- Mega Edition only
    App("office", "Writer", "libreoffice-writer", "libreoffice --writer %U", ("libreoffice-writer.desktop",), "Office", True, "app_office"),
    App("photo", "GIMP", "gimp", "gimp %U", ("gimp.desktop",), "Graphics", True, "app_photo"),
    App("video", "VLC", "vlc", "vlc %U", ("vlc.desktop",), "Multimedia", True, "app_video"),
    App("music", "Audacious", "audacious", "audacious %U", ("audacious.desktop",), "Multimedia", True, "app_music"),
    App("pdf", "PDF Reader", "org.gnome.Evince", "evince %U", ("org.gnome.Evince.desktop", "evince.desktop"), "Office", True, ""),
    App("screenshot", "Screenshot", "org.xfce.screenshooter", "xfce4-screenshooter", ("org.xfce.screenshooter.desktop", "xfce4-screenshooter.desktop"), "Accessories", True, ""),
    App("monitor", "Task Manager", "org.xfce.taskmanager", "xfce4-taskmanager", ("org.xfce.taskmanager.desktop", "xfce4-taskmanager.desktop"), "System", True, ""),
    App("store", "Software", "org.gnome.Software", "gnome-software", ("org.gnome.Software.desktop",), "System", True, "app_store"),
)
APP_BY_KEY = {a.key: a for a in APPS}

# Apps shown in the "explore apps" slideshow while Calamares installs.
GALLERY = {
    "mega": ("browser", "files", "office", "photo", "video", "music", "store"),
    "original": ("browser", "files", "editor", "terminal", "calc", "viewer", "media"),
}

# Taskbar quick-launch apps (middle segment).
TASKBAR_PINNED = ("browser", "files", "terminal")


def apps_for(edition: str):
    """Apps that exist in the given edition."""
    return [a for a in APPS if edition == "mega" or not a.mega_only]


def default_pinned(edition: str):
    base = ["browser", "files", "terminal", "editor", "settings"]
    if edition == "mega":
        base += ["office", "video", "store"]
    return base


# ---------------------------------------------------------------- start menu categories
# Names must match the <Name> of the sub-menus in /etc/xdg/menus/xfce-applications.menu.
MENU_CATEGORIES = ("Accessories", "Games", "Graphics", "Internet", "Multimedia", "Office", "Settings", "System")

# ---------------------------------------------------------------- colours
PALETTE = (
    "#2ABAA3",  # EverestOS teal (default)
    "#3B82F6",  # blue
    "#6366F1",  # indigo
    "#A855F7",  # purple
    "#EC4899",  # pink
    "#EF4444",  # red
    "#F97316",  # orange
    "#EAB308",  # amber
    "#22C55E",  # green
    "#94A3B8",  # graphite
)
