"""Turn a SetupState into the per-user desktop configuration (XFCE 4.18/4.20).

Used twice:
  * at ISO build time to produce the default /etc/skel (Mega Edition, teal accent), and
  * at install time by the Calamares job, to write the user's own choices.

Taskbar design (from the supplied reference): three separate dark, rounded segments on the
LEFT edge -- top: logo (start menu) [+ search in Mega]; middle: pinned and running apps;
bottom: quick-notes pencil + clock.  In XFCE that is three small floating vertical panels.
"""
from xml.sax.saxutils import escape

from . import catalog

WALLPAPER = "/usr/share/backgrounds/everestos/wallpaper.jpg"   # the mountain photo
SAVER_THEME_ID = "screensavers-everestos-clock.desktop"       # see desktop/usr/share/applications/screensavers
PANEL_SIZE = 52       # thickness (px) of the vertical bars
ICON_SIZE = 28
DARK = "#0E0F10"      # taskbar segment colour, as in the reference

# plugin ids
P_WHISKER, P_SEARCH, P_BROWSER, P_FILES, P_TERMINAL, P_TASKS, P_NOTES, P_CLOCK = 1, 2, 3, 4, 5, 6, 7, 8


# ----------------------------------------------------------------- colour helpers
def _rgb(hex_color):
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _hex(rgb):
    return "#%02X%02X%02X" % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def shade(hex_color, factor):
    """factor < 1 darkens, > 1 lightens (towards white)."""
    r, g, b = _rgb(hex_color)
    if factor <= 1:
        return _hex((r * factor, g * factor, b * factor))
    t = factor - 1
    return _hex((r + (255 - r) * t, g + (255 - g) * t, b + (255 - b) * t))


def contrast_text(hex_color):
    r, g, b = _rgb(hex_color)
    return "#0B0B0B" if (0.299 * r + 0.587 * g + 0.114 * b) > 160 else "#FFFFFF"


# ----------------------------------------------------------------- geometry
def compute_geometry(width, height, search, size=PANEL_SIZE):
    """Pixel position of the three segments for a given screen size.

    Proportions follow the reference screenshot (gap at the top, tall middle segment, bottom
    segment near the lower edge).  Top/bottom segments shrink to fit their icons
    (length-adjust), the middle one is a percentage of the screen height.
    """
    x = max(6, int(width * 0.0045)) if width < 1000 else 12
    top_h = (2 if search else 1) * size
    bottom_h = 2 * size
    top_y = max(16, int(height * 0.024))
    bottom_y = height - 24 - bottom_h
    mid_y = max(int(height * 0.21), top_y + top_h + 12)
    mid_end = min(int(height * 0.78), bottom_y - 12)
    mid_len_px = max(size * 3, mid_end - mid_y)
    return {
        1: {"x": x, "y": top_y, "length": 1, "adjust": True},
        2: {"x": x, "y": mid_y, "length": max(10, min(90, round(mid_len_px * 100 / height))), "adjust": False},
        3: {"x": x, "y": bottom_y, "length": 1, "adjust": True},
    }


# ----------------------------------------------------------------- panel
def _panel(pid, geo, plugin_ids):
    ids = "\n".join('        <value type="int" value="%d"/>' % i for i in plugin_ids)
    return f'''    <property name="panel-{pid}" type="empty">
      <property name="position" type="string" value="p=0;x={geo['x']};y={geo['y']}"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="mode" type="uint" value="1"/>
      <property name="size" type="uint" value="{PANEL_SIZE}"/>
      <property name="icon-size" type="uint" value="{ICON_SIZE}"/>
      <property name="nrows" type="uint" value="1"/>
      <property name="length" type="uint" value="{geo['length']}"/>
      <property name="length-adjust" type="bool" value="{str(geo['adjust']).lower()}"/>
      <property name="background-style" type="uint" value="0"/>
      <property name="enable-struts" type="bool" value="false"/>
      <property name="plugin-ids" type="array">
{ids}
      </property>
    </property>'''


def render_panel_xml(search, width=1920, height=1080):
    geo = compute_geometry(width, height, search)
    p1 = [P_WHISKER] + ([P_SEARCH] if search else [])
    p2 = [P_BROWSER, P_FILES, P_TERMINAL, P_TASKS]
    p3 = [P_NOTES, P_CLOCK]
    plugins = [
        '    <property name="plugin-%d" type="string" value="whiskermenu"/>' % P_WHISKER,
    ]
    if search:
        plugins.append(_launcher(P_SEARCH, "everest-search.desktop"))
    plugins += [
        _launcher(P_BROWSER, "everest-browser.desktop"),
        _launcher(P_FILES, "everest-files.desktop"),
        _launcher(P_TERMINAL, "everest-terminal.desktop"),
        f'''    <property name="plugin-{P_TASKS}" type="string" value="tasklist">
      <property name="grouping" type="uint" value="1"/>
      <property name="show-labels" type="bool" value="false"/>
      <property name="flat-buttons" type="bool" value="true"/>
      <property name="show-handle" type="bool" value="false"/>
      <property name="include-all-workspaces" type="bool" value="false"/>
    </property>''',
        _launcher(P_NOTES, "everest-notes.desktop"),
        f'''    <property name="plugin-{P_CLOCK}" type="string" value="clock">
      <property name="mode" type="uint" value="0"/>
      <property name="tooltip-format" type="string" value="%A, %d %B %Y"/>
    </property>''',
    ]
    return f'''<?xml version="1.0" encoding="UTF-8"?>

<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <value type="int" value="2"/>
    <value type="int" value="3"/>
    <property name="dark-mode" type="bool" value="true"/>
{_panel(1, geo[1], p1)}
{_panel(2, geo[2], p2)}
{_panel(3, geo[3], p3)}
  </property>
  <property name="plugins" type="empty">
{chr(10).join(plugins)}
  </property>
</channel>
'''


def _launcher(pid, item):
    return f'''    <property name="plugin-{pid}" type="string" value="launcher">
      <property name="items" type="array">
        <value type="string" value="{item}"/>
      </property>
      <property name="disable-tooltips" type="bool" value="false"/>
    </property>'''


def _desktop_entry(name, exec_, icon, comment="", terminal=False):
    return ("[Desktop Entry]\nVersion=1.0\nType=Application\nName=%s\nComment=%s\nExec=%s\nIcon=%s\n"
            "Terminal=%s\nStartupNotify=true\n") % (name, comment, exec_, icon, str(terminal).lower())


def launcher_files(search):
    """{plugin_id: {filename: content}} for the generated quick-launch entries."""
    out = {}
    for pid, key in ((P_BROWSER, "browser"), (P_FILES, "files"), (P_TERMINAL, "terminal")):
        a = catalog.APP_BY_KEY[key]
        out[pid] = {"everest-%s.desktop" % key: _desktop_entry(a.name, a.exec, a.icon)}
    out[P_NOTES] = {"everest-notes.desktop": _desktop_entry(
        "Quick Notes",
        "sh -c 'mkdir -p \"$HOME/Documents\" && exec mousepad \"$HOME/Documents/Quick Notes.txt\"'",
        "document-edit", "Jot something down")}
    if search:
        out[P_SEARCH] = {"everest-search.desktop": _desktop_entry(
            "Search", "everestos-search", "system-search", "Search apps, files and the web")}
    return out


# ----------------------------------------------------------------- start menu
def resolve_pinned(keys, exists=None):
    ids = []
    for k in keys:
        app = catalog.APP_BY_KEY.get(k)
        if not app:
            continue
        if exists is None:
            ids.extend(app.ids)  # build time: list every candidate, unknown ids are ignored
        else:
            for i in app.ids:
                if exists(i):
                    ids.append(i)
                    break
    return ids


def render_whisker_rc(state, exists=None):
    grid = state.menu_style == "grid"
    favorites = ",".join(resolve_pinned(state.menu_pinned, exists))
    return f'''favorites={favorites}
recent=
button-title=EverestOS
button-icon=everestos-logo
button-single-row=false
show-button-title=false
show-button-icon=true
launcher-show-name=true
launcher-show-description={'false' if grid else 'true'}
launcher-show-tooltip=true
item-icon-size={4 if grid else 2}
hover-switch-category=false
category-show-name=true
category-icon-size=1
load-hierarchy=false
view-as-icons={'true' if grid else 'false'}
default-category={0 if state.menu_recent else 1}
recent-items-max={10 if state.menu_recent else 0}
favorites-in-recent=true
display-recent-default=false
position-search-alternate=true
position-commands-alternate=false
position-categories-alternate=true
stay-on-focus-out=false
confirm-session-command=true
menu-width={560 if grid else 460}
menu-height={560 if grid else 520}
menu-opacity=100
command-settings=xfce4-settings-manager
'''


def render_menu_file(state):
    """~/.config/menus/xfce-applications.menu hiding the categories the user switched off."""
    hidden = [c for c in catalog.MENU_CATEGORIES if c not in state.menu_categories]
    if not hidden:
        return None
    subs = "\n".join("  <Menu>\n    <Name>%s</Name>\n    <Deleted/>\n  </Menu>" % escape(c) for c in hidden)
    return f'''<!DOCTYPE Menu PUBLIC "-//freedesktop//DTD Menu 1.0//EN"
 "http://www.freedesktop.org/standards/menu-spec/menu-1.0.dtd">
<Menu>
  <Name>Xfce</Name>
  <MergeFile type="parent">/etc/xdg/menus/xfce-applications.menu</MergeFile>
{subs}
</Menu>
'''


# ----------------------------------------------------------------- GTK / colours
def render_gtk_css(accent):
    hi = shade(accent, 1.25)
    lo = shade(accent, 0.72)
    fg = contrast_text(accent)
    return f'''/* EverestOS accent: {accent} */
@define-color accent_color {accent};
@define-color accent_bg_color {accent};
@define-color accent_fg_color {fg};
@define-color theme_selected_bg_color {accent};
@define-color theme_selected_fg_color {fg};
@define-color selected_bg_color {accent};
@define-color selected_fg_color {fg};
@define-color theme_unfocused_selected_bg_color {lo};
@define-color link_color {hi};
@define-color link_visited_color {lo};

/* rounded dark taskbar segments (needs the xfwm4 compositor, which is on by default) */
#XfcePanelWindow, .xfce4-panel.background {{
  background-color: rgba(14, 15, 16, 0.97);
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.05);
}}
.xfce4-panel button {{ border-radius: 10px; background: transparent; border: none; box-shadow: none; }}
.xfce4-panel button:hover {{ background-color: alpha({accent}, 0.25); }}
.xfce4-panel button:checked, .xfce4-panel button:active {{ background-color: alpha({accent}, 0.45); }}
'''


def render_gtk_settings():
    return ("[Settings]\ngtk-theme-name=Adwaita-dark\ngtk-icon-theme-name=Papirus-Dark\n"
            "gtk-application-prefer-dark-theme=1\ngtk-font-name=Noto Sans 10\n")


def render_xsettings_xml():
    return '''<?xml version="1.0" encoding="UTF-8"?>

<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="Adwaita-dark"/>
    <property name="IconThemeName" type="string" value="Papirus-Dark"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="FontName" type="string" value="Noto Sans 10"/>
    <property name="MonospaceFontName" type="string" value="Noto Sans Mono 10"/>
  </property>
  <property name="Xft" type="empty">
    <property name="Antialias" type="int" value="1"/>
    <property name="Hinting" type="int" value="1"/>
    <property name="HintStyle" type="string" value="hintslight"/>
    <property name="RGBA" type="string" value="rgb"/>
  </property>
</channel>
'''


def render_xfwm4_xml():
    return '''<?xml version="1.0" encoding="UTF-8"?>

<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="Default"/>
    <property name="title_font" type="string" value="Noto Sans Bold 10"/>
    <property name="use_compositing" type="bool" value="true"/>
    <property name="button_layout" type="string" value="O|HMC"/>
    <property name="show_dock_shadow" type="bool" value="true"/>
  </property>
</channel>
'''


_MONITORS = ("monitor0", "monitorVirtual-1", "monitorVGA-1", "monitorVGA-0", "monitorDP-1", "monitoreDP-1",
             "monitorHDMI-1", "monitorLVDS-1")


def render_desktop_xml():
    mons = "\n".join(f'''      <property name="{m}" type="empty">
        <property name="workspace0" type="empty">
          <property name="color-style" type="int" value="0"/>
          <property name="image-style" type="int" value="5"/>
          <property name="last-image" type="string" value="{WALLPAPER}"/>
        </property>
      </property>''' for m in _MONITORS)
    return f'''<?xml version="1.0" encoding="UTF-8"?>

<channel name="xfce4-desktop" version="1.0">
  <property name="backdrop" type="empty">
    <property name="screen0" type="empty">
{mons}
    </property>
  </property>
</channel>
'''


# ----------------------------------------------------------------- lock screen
def render_session_xml():
    """Make xflock4 (Super+L, menu, Ctrl+Alt+L) call xfce4-screensaver explicitly."""
    return '''<?xml version="1.0" encoding="UTF-8"?>

<channel name="xfce4-session" version="1.0">
  <property name="general" type="empty">
    <property name="LockCommand" type="string" value="xfce4-screensaver-command --lock"/>
  </property>
</channel>
'''


def render_screensaver_xml(idle_minutes=10):
    """Lock screen = xfce4-screensaver (real PAM-checked locker) running the EverestOS clock saver.

    saver/mode 2 + a one-item theme list selects our saver whether the enum reads "single" or
    "random"; users can change it in Settings > Screensaver.
    """
    return f'''<?xml version="1.0" encoding="UTF-8"?>

<channel name="xfce4-screensaver" version="1.0">
  <property name="saver" type="empty">
    <property name="enabled" type="bool" value="true"/>
    <property name="mode" type="int" value="2"/>
    <property name="idle-activation" type="empty">
      <property name="enabled" type="bool" value="true"/>
      <property name="delay" type="int" value="{idle_minutes}"/>
    </property>
    <property name="themes" type="empty">
      <property name="list" type="array">
        <value type="string" value="{SAVER_THEME_ID}"/>
      </property>
    </property>
  </property>
  <property name="lock" type="empty">
    <property name="enabled" type="bool" value="true"/>
    <property name="saver-activation" type="empty">
      <property name="enabled" type="bool" value="true"/>
      <property name="delay" type="int" value="0"/>
    </property>
    <property name="user-switching" type="empty">
      <property name="enabled" type="bool" value="true"/>
    </property>
  </property>
</channel>
'''


# ----------------------------------------------------------------- input methods
def render_xsessionrc(ime):
    if not ime:
        return None
    return ("# EverestOS: input method for your language (fcitx5)\n"
            "export GTK_IM_MODULE=fcitx\nexport QT_IM_MODULE=fcitx\nexport XMODIFIERS=@im=fcitx\n")


def render_fcitx_profile(ime, layout="us"):
    if not ime:
        return None
    first = layout.split(",")[0]
    engine = {"hangul": "hangul", "mozc": "mozc", "pinyin": "pinyin"}[ime]
    return f'''[Groups/0]
Name=Default
Default Layout={first}
DefaultIM={engine}

[Groups/0/Items/0]
Name=keyboard-{first}
Layout=

[Groups/0/Items/1]
Name={engine}
Layout=

[GroupOrder]
0=Default
'''


# ----------------------------------------------------------------- the whole bundle
def render_user_config(state, exists=None, width=1920, height=1080):
    """Return {path relative to $HOME: text} for everything the wizard customises."""
    cfg = ".config/"
    files = {
        cfg + "xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml": render_panel_xml(state.search, width, height),
        cfg + "xfce4/xfconf/xfce-perchannel-xml/xsettings.xml": render_xsettings_xml(),
        cfg + "xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml": render_xfwm4_xml(),
        cfg + "xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml": render_desktop_xml(),
        cfg + "xfce4/xfconf/xfce-perchannel-xml/xfce4-screensaver.xml": render_screensaver_xml(),
        cfg + "xfce4/xfconf/xfce-perchannel-xml/xfce4-session.xml": render_session_xml(),
        cfg + "xfce4/panel/whiskermenu-%d.rc" % P_WHISKER: render_whisker_rc(state, exists),
        cfg + "gtk-3.0/gtk.css": render_gtk_css(state.accent),
        cfg + "gtk-3.0/settings.ini": render_gtk_settings(),
        cfg + "everestos/settings.json": state.to_json_public() if hasattr(state, "to_json_public") else "{}\n",
    }
    for pid, entries in launcher_files(state.search).items():
        for name, text in entries.items():
            files[cfg + "xfce4/panel/launcher-%d/%s" % (pid, name)] = text
    menu = render_menu_file(state)
    if menu:
        files[cfg + "menus/xfce-applications.menu"] = menu
    lang = state.lang
    rc = render_xsessionrc(lang.ime)
    if rc:
        files[".xsessionrc"] = rc
        files[cfg + "fcitx5/profile"] = render_fcitx_profile(lang.ime, state.keyboard_layout)
    return files
