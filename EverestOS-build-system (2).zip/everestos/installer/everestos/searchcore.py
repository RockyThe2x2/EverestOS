"""Logic of the Mega-Edition search popup (no GUI imports, so it can be unit-tested)."""
import os
import shutil
import subprocess
import urllib.parse

WEB = "https://duckduckgo.com/?q="


def web_url(query):
    return WEB + urllib.parse.quote_plus(query.strip())


def match_apps(query, apps, limit=6):
    """apps: iterable of (name, comment, id).  Prefix matches rank above substring matches."""
    q = query.strip().lower()
    if not q:
        return []
    scored = []
    for name, comment, ident in apps:
        n = (name or "").lower()
        if n.startswith(q):
            scored.append((0, n, name, ident))
        elif q in n:
            scored.append((1, n, name, ident))
        elif q in (comment or "").lower():
            scored.append((2, n, name, ident))
    scored.sort()
    return [(name, ident) for _, _, name, ident in scored[:limit]]


def find_files(query, home=None, limit=6, runner=None):
    """Case-insensitive file-name search: plocate if available, else a shallow walk of $HOME."""
    q = query.strip()
    if len(q) < 2:
        return []
    home = home or os.path.expanduser("~")
    if shutil.which("plocate") and runner is None:
        try:
            out = subprocess.run(["plocate", "-i", "-l", str(limit * 4), "-b", q],
                                 capture_output=True, text=True, timeout=3).stdout.splitlines()
            return [p for p in out if p.startswith(home) and "/." not in p][:limit]
        except (OSError, subprocess.SubprocessError):
            pass
    hits, ql = [], q.lower()
    base_depth = home.rstrip("/").count("/")
    for root, dirs, files in os.walk(home):
        if root.count("/") - base_depth >= 4:
            dirs[:] = []
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for name in dirs + files:
            if ql in name.lower():
                hits.append(os.path.join(root, name))
                if len(hits) >= limit:
                    return hits
    return hits
