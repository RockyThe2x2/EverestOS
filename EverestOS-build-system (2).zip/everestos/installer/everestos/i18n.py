"""Tiny gettext-like translation layer backed by strings.txt (also exportable to .po)."""
import os
import re

from .catalog import LANG_BY_CODE, SHORT_CODES

_HERE = os.path.dirname(os.path.abspath(__file__))
_KEY = re.compile(r"^\[(\w+)\]\s*$")
_LINE = re.compile(r"^([a-z]{2})\s*=\s*(.*)$")


def load(path=None):
    """Return {key: {short_lang: text}}."""
    path = path or os.path.join(_HERE, "strings.txt")
    table, key = {}, None
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            m = _KEY.match(line)
            if m:
                key = m.group(1)
                table[key] = {}
                continue
            m = _LINE.match(line)
            if m and key:
                table[key][m.group(1)] = m.group(2).strip()
    return table


_TABLE = None


def table():
    global _TABLE
    if _TABLE is None:
        _TABLE = load()
    return _TABLE


class Translator:
    """t = Translator('ru_RU');  t('next');  t('step_of', n=1, total=5)"""

    def __init__(self, locale="en_US"):
        self.set_language(locale)

    def set_language(self, locale):
        lang = LANG_BY_CODE.get(locale)
        self.short = lang.short if lang else "en"
        self.locale = locale if lang else "en_US"

    def __call__(self, key, **kw):
        entry = table().get(key)
        if entry is None:
            return key  # visible, never crashes
        text = entry.get(self.short) or entry.get("en", key)
        if kw:
            try:
                text = text.format(**kw)
            except (KeyError, IndexError):
                pass
        return text


def export_po(out_dir):
    """Write po/everestos.pot and one <lang>.po per language (for translators)."""
    os.makedirs(out_dir, exist_ok=True)
    keys = list(table().keys())

    def esc(s):
        return s.replace("\\", "\\\\").replace('"', '\\"')

    def write(path, lang):
        with open(path, "w", encoding="utf-8") as fh:
            fh.write('msgid ""\nmsgstr ""\n"Project-Id-Version: EverestOS 1.0\\n"\n"MIME-Version: 1.0\\n"\n'
                     '"Content-Type: text/plain; charset=UTF-8\\n"\n"Content-Transfer-Encoding: 8bit\\n"\n')
            if lang:
                fh.write('"Language: %s\\n"\n' % lang)
            fh.write("\n")
            for k in keys:
                en = table()[k]["en"]
                fh.write("#. key: %s\n" % k)
                fh.write('msgid "%s"\n' % esc(en))
                tr = "" if not lang or lang == "en" else table()[k].get(lang, "")
                fh.write('msgstr "%s"\n\n' % esc(tr))

    write(os.path.join(out_dir, "everestos.pot"), None)
    for short in SHORT_CODES:
        write(os.path.join(out_dir, short + ".po"), short)
