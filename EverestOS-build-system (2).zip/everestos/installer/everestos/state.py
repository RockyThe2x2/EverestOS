"""Everything the user chooses in the wizard, with validation and (de)serialisation."""
import json
import os
import re
from dataclasses import asdict, dataclass, field

from . import catalog

USERNAME_RE = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")
HOSTNAME_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$")
HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
RESERVED_USERS = {
    "root", "daemon", "bin", "sys", "sync", "games", "man", "lp", "mail", "news", "uucp", "proxy",
    "www-data", "backup", "list", "irc", "nobody", "live", "user", "admin", "sudo", "systemd-network",
}
MIN_PASSWORD = 6


@dataclass
class SetupState:
    language: str = "en_US"
    keyboard_layout: str = "us"
    keyboard_options: str = ""
    timezone: str = "UTC"
    edition: str = "mega"                 # "mega" | "original"
    fullname: str = ""
    username: str = ""
    hostname: str = "everestos"
    password: str = ""
    accent: str = catalog.DEFAULT_ACCENT
    menu_style: str = "list"              # "list" | "grid"
    menu_pinned: list = field(default_factory=lambda: catalog.default_pinned("mega"))
    menu_categories: list = field(default_factory=lambda: list(catalog.MENU_CATEGORIES))
    menu_recent: bool = True

    # ---- derived helpers
    @property
    def lang(self):
        return catalog.LANG_BY_CODE.get(self.language, catalog.LANGUAGES[0])

    @property
    def edition_obj(self):
        return catalog.EDITIONS[self.edition]

    @property
    def search(self) -> bool:
        return self.edition_obj.search

    def set_edition(self, edition):
        """Switch edition and drop pinned apps that don't exist in it."""
        self.edition = edition
        allowed = {a.key for a in catalog.apps_for(edition)}
        self.menu_pinned = [k for k in self.menu_pinned if k in allowed] or catalog.default_pinned(edition)

    # ---- validation: returns a list of strings.txt keys describing what is wrong
    def validate_name_page(self, password2=None):
        errors = []
        if not self.fullname.strip():
            errors.append("err_name")
        if not valid_username(self.username):
            errors.append("err_username")
        if not valid_hostname(self.hostname):
            errors.append("err_hostname")
        if not valid_password(self.password) or (password2 is not None and password2 != self.password):
            errors.append("err_password")
        return errors

    def validate(self):
        errors = self.validate_name_page()
        if self.edition not in catalog.EDITIONS:
            errors.append("bad_edition")
        if not valid_hex(self.accent):
            errors.append("bad_accent")
        if self.menu_style not in ("list", "grid"):
            errors.append("bad_menu_style")
        if self.language not in catalog.LANG_BY_CODE:
            errors.append("bad_language")
        tz = self.timezone or ""
        if not re.match(r"^[A-Za-z0-9_+./-]+$", tz) or ".." in tz or tz.startswith("/"):
            errors.append("bad_timezone")
        if not re.match(r"^[a-z0-9,_-]+$", self.keyboard_layout or ""):
            errors.append("bad_keyboard")
        if not re.match(r"^[A-Za-z0-9:,_-]*$", self.keyboard_options or ""):
            errors.append("bad_keyboard")
        return errors

    # ---- (de)serialisation
    def to_json(self):
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)

    def to_json_public(self):
        """Same as to_json() but without the password (safe to leave in the user's home)."""
        data = asdict(self)
        data.pop("password", None)
        return json.dumps(data, ensure_ascii=False, indent=2) + "\n"

    @classmethod
    def from_json(cls, text):
        data = json.loads(text)
        known = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**known)

    def save(self, path):
        """Write with mode 0600 (it contains the password)."""
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(self.to_json())

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as fh:
            return cls.from_json(fh.read())


def valid_username(u):
    return bool(u) and bool(USERNAME_RE.match(u)) and u not in RESERVED_USERS


def valid_hostname(h):
    return bool(h) and bool(HOSTNAME_RE.match(h))


def valid_password(p):
    return len(p or "") >= MIN_PASSWORD and "\n" not in p


def valid_hex(c):
    return bool(HEX_RE.match(c or ""))


def suggest_username(fullname):
    """'Иван Петров' -> 'user' fallback; 'John Smith' -> 'john'."""
    first = (fullname.strip().split() or [""])[0].lower()
    ascii_only = re.sub(r"[^a-z0-9_-]", "", first)
    if not ascii_only or not ascii_only[0].isalpha():
        return ""
    return ascii_only[:32]
