"""Search popup of the Mega Edition (taskbar search icon): apps, files and the web in one box."""
import os
import subprocess
import sys

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gio, Gtk  # noqa: E402

from . import searchcore  # noqa: E402
from .i18n import Translator  # noqa: E402


def session_translator():
    loc = (os.environ.get("LANG") or "en_US").split(".")[0]
    return Translator(loc)


class SearchWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Search")
        self.t = session_translator()
        self.apps = [(a.get_display_name(), a.get_description() or "", a) for a in Gio.AppInfo.get_all()
                     if a.should_show()]
        self.set_default_size(620, 420)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_decorated(False)
        self.connect("focus-out-event", lambda *_: Gtk.main_quit())
        self.connect("key-press-event", self.on_key)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for side in ("top", "bottom", "start", "end"):
            getattr(box, "set_margin_" + side)(14)
        self.entry = Gtk.Entry()
        self.entry.set_placeholder_text(self.t("search_placeholder"))
        self.entry.connect("changed", self.refresh)
        self.entry.connect("activate", lambda *_: self.activate_row(self.list.get_row_at_index(0)))
        self.list = Gtk.ListBox()
        self.list.connect("row-activated", lambda _l, row: self.activate_row(row))
        box.pack_start(self.entry, False, False, 0)
        box.pack_start(self.list, True, True, 0)
        self.add(box)
        self.actions = []
        self.show_all()

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            Gtk.main_quit()

    def refresh(self, entry):
        for row in self.list.get_children():
            self.list.remove(row)
        self.actions = []
        q = entry.get_text().strip()
        if not q:
            return
        by_name = {name: info for name, _c, info in self.apps}
        for name, _ident in searchcore.match_apps(q, [(n, c, n) for n, c, _i in self.apps]):
            self.add_row(name, lambda info=by_name[name]: info.launch([], None))
        for path in searchcore.find_files(q):
            self.add_row(os.path.basename(path) + "   " + os.path.dirname(path),
                         lambda p=path: subprocess.Popen(["xdg-open", p]))
        self.add_row(self.t("search_web", q=q), lambda: subprocess.Popen(["xdg-open", searchcore.web_url(q)]))
        self.list.show_all()
        self.list.select_row(self.list.get_row_at_index(0))

    def add_row(self, text, action):
        label = Gtk.Label(label=text, xalign=0)
        label.set_margin_top(8)
        label.set_margin_bottom(8)
        label.set_margin_start(10)
        row = Gtk.ListBoxRow()
        row.add(label)
        self.list.add(row)
        self.actions.append(action)

    def activate_row(self, row):
        if row is None:
            return
        try:
            self.actions[row.get_index()]()
        finally:
            Gtk.main_quit()


def main(argv=None):
    SearchWindow()
    Gtk.main()
    return 0
