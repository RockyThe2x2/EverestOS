"""EverestOS Setup wizard (GTK 3).

Pages:  language -> 1 edition -> 2 name -> 3 colour -> 4 start menu -> 5 install
Step 5 is Calamares: it asks which disk to erase, then shows the "explore your apps"
slideshow while the system installs in the background.
"""
import math
import os
import subprocess
import sys

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import catalog  # noqa: E402
from .i18n import Translator  # noqa: E402
from .state import SetupState, suggest_username  # noqa: E402

LAUNCHER = "/usr/lib/everestos/launch-installer"
DONE_FLAG = "/run/everestos-installed"
PAGES = ("language", "edition", "name", "color", "menu")


# ---------------------------------------------------------------- drawing helpers
def _rgb(hex_color):
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def rounded(cr, x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


def draw_logo(cr, x, y, size, color):
    """The EverestOS mark (same geometry as assets/logo.svg) inside a size x size box."""
    s = size / 1067.0
    cr.set_source_rgb(*_rgb(color))
    for x0, y0, x1, y1 in ((271, 15, 1071, 816), (12, 169, 197, 1067), (12, 891, 907, 1067)):
        cr.rectangle(x + x0 * s, y + y0 * s, (x1 - x0) * s, (y1 - y0) * s)
    cr.fill()


def draw_search_icon(cr, cx, cy, r, color):
    cr.set_source_rgb(*_rgb(color))
    cr.set_line_width(max(1.2, r * 0.22))
    cr.arc(cx - r * 0.2, cy - r * 0.2, r * 0.7, 0, 2 * math.pi)
    cr.stroke()
    cr.move_to(cx + r * 0.3, cy + r * 0.3)
    cr.line_to(cx + r * 0.9, cy + r * 0.9)
    cr.stroke()


def draw_desktop_mock(cr, w, h, accent, search, with_window=False):
    """Mini desktop: mountain-ish gradient, the three taskbar segments, optional window."""
    cr.set_source_rgb(0.10, 0.13, 0.14)
    rounded(cr, 0, 0, w, h, 12)
    cr.fill()
    cr.set_source_rgb(0.22, 0.27, 0.29)
    cr.move_to(w * 0.25, h)
    cr.line_to(w * 0.55, h * 0.30)
    cr.line_to(w * 0.75, h * 0.55)
    cr.line_to(w * 0.88, h * 0.40)
    cr.line_to(w, h * 0.7)
    cr.line_to(w, h)
    cr.close_path()
    cr.fill()
    bar_w, gap = max(14, w * 0.09), 6
    # top segment
    top_h = bar_w * (2.0 if search else 1.1)
    cr.set_source_rgb(0.055, 0.06, 0.063)
    rounded(cr, gap, h * 0.06, bar_w, top_h, 6)
    cr.fill()
    draw_logo(cr, gap + bar_w * 0.2, h * 0.06 + bar_w * 0.15, bar_w * 0.6, accent)
    if search:
        draw_search_icon(cr, gap + bar_w / 2, h * 0.06 + bar_w * 1.45, bar_w * 0.2, "#FFFFFF")
    # middle segment
    cr.set_source_rgb(0.055, 0.06, 0.063)
    rounded(cr, gap, h * 0.30, bar_w, h * 0.38, 6)
    cr.fill()
    # bottom segment
    rounded(cr, gap, h * 0.78, bar_w, h * 0.17, 6)
    cr.fill()
    cr.set_source_rgb(1, 1, 1)
    cr.set_line_width(1.5)
    cr.arc(gap + bar_w / 2, h * 0.885, bar_w * 0.22, 0, 2 * math.pi)
    cr.stroke()
    cr.move_to(gap + bar_w * 0.3, h * 0.82)
    cr.line_to(gap + bar_w * 0.7, h * 0.80)
    cr.stroke()
    if with_window:
        wx, wy, ww, wh = w * 0.30, h * 0.18, w * 0.52, h * 0.55
        cr.set_source_rgb(0.12, 0.13, 0.14)
        rounded(cr, wx, wy, ww, wh, 8)
        cr.fill()
        cr.set_source_rgb(*_rgb(accent))
        rounded(cr, wx, wy, ww, wh * 0.16, 8)
        cr.fill()
        cr.rectangle(wx, wy + wh * 0.10, ww, wh * 0.06)
        cr.fill()
        for i in range(3):
            cr.set_source_rgb(0.25, 0.27, 0.28)
            rounded(cr, wx + ww * 0.08, wy + wh * (0.30 + 0.20 * i), ww * 0.55, wh * 0.08, 3)
            cr.fill()
        cr.set_source_rgb(*_rgb(accent))
        rounded(cr, wx + ww * 0.08, wy + wh * 0.30, ww * 0.35, wh * 0.08, 3)
        cr.fill()


def draw_menu_mock(cr, w, h, st):
    cr.set_source_rgb(0.055, 0.06, 0.063)
    rounded(cr, 0, 0, w, h, 14)
    cr.fill()
    accent = st.accent
    cr.set_source_rgb(0.15, 0.17, 0.18)
    rounded(cr, 14, 14, w - 28, 26, 8)
    cr.fill()
    draw_search_icon(cr, 30, 27, 6, "#9AA4A6")
    n_cat = len(st.menu_categories)
    rail = 14
    for i in range(min(n_cat, 8)):
        cr.set_source_rgb(*_rgb(accent if i == 0 else "#33383A"))
        rounded(cr, 14, 54 + i * (rail + 6), 46, rail, 5)
        cr.fill()
    pinned = [catalog.APP_BY_KEY[k] for k in st.menu_pinned if k in catalog.APP_BY_KEY]
    x0, y0 = 74, 54
    if st.menu_style == "grid":
        cols = 4
        cell = (w - x0 - 14) / cols
        for i, _ in enumerate(pinned[:16]):
            cx, cy = x0 + (i % cols) * cell, y0 + (i // cols) * (cell * 0.95)
            cr.set_source_rgb(*_rgb(accent))
            rounded(cr, cx + cell * 0.15, cy, cell * 0.55, cell * 0.55, 8)
            cr.fill()
            cr.set_source_rgb(0.35, 0.38, 0.40)
            rounded(cr, cx + cell * 0.12, cy + cell * 0.65, cell * 0.62, 4, 2)
            cr.fill()
    else:
        for i, _ in enumerate(pinned[:9]):
            cy = y0 + i * 30
            cr.set_source_rgb(*_rgb(accent))
            rounded(cr, x0, cy, 20, 20, 5)
            cr.fill()
            cr.set_source_rgb(0.5, 0.54, 0.56)
            rounded(cr, x0 + 30, cy + 7, (w - x0 - 60) * (0.5 + 0.08 * (i % 4)), 6, 3)
            cr.fill()
    if st.menu_recent:
        cr.set_source_rgb(*_rgb("#33383A"))
        rounded(cr, 74, h - 30, w - 88, 14, 5)
        cr.fill()


# ---------------------------------------------------------------- widgets
class Preview(Gtk.DrawingArea):
    def __init__(self, painter, width, height):
        super().__init__()
        self.set_size_request(width, height)
        self._painter = painter
        self.connect("draw", self._on_draw)

    def _on_draw(self, widget, cr):
        a = widget.get_allocation()
        self._painter(cr, a.width, a.height)
        return False


class Card(Gtk.EventBox):
    """Clickable selectable card (edition choice)."""

    def __init__(self, on_click):
        super().__init__()
        self.set_visible_window(True)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", lambda *_: on_click())
        self.get_style_context().add_class("card")

    def set_selected(self, selected):
        ctx = self.get_style_context()
        (ctx.add_class if selected else ctx.remove_class)("selected")


class Swatch(Gtk.EventBox):
    def __init__(self, color, on_click):
        super().__init__()
        self.color = color
        self.selected = False
        self.set_size_request(54, 54)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", lambda *_: on_click(color))
        area = Gtk.DrawingArea()
        area.connect("draw", self._draw)
        self.add(area)
        self._area = area

    def _draw(self, widget, cr):
        a = widget.get_allocation()
        cx, cy, r = a.width / 2, a.height / 2, min(a.width, a.height) / 2 - 5
        cr.set_source_rgb(*_rgb(self.color))
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.fill()
        if self.selected:
            cr.set_source_rgb(1, 1, 1)
            cr.set_line_width(3)
            cr.arc(cx, cy, r + 3, 0, 2 * math.pi)
            cr.stroke()
        return False

    def set_selected(self, sel):
        self.selected = sel
        self._area.queue_draw()


def css_for(accent):
    return f"""
window, .root {{ background-color: #0E1011; color: #FFFFFF; }}
label {{ color: #E8ECEC; }}
.title {{ font-size: 30px; font-weight: bold; color: #FFFFFF; }}
.sub {{ font-size: 15px; color: #9AA4A6; }}
.err {{ color: #FF7A7A; }}
.step {{ padding: 6px 14px; border-radius: 16px; background: #1A1D1F; color: #7C8789; }}
.step-active {{ background: {accent}; color: #0B0B0B; font-weight: bold; }}
.step-done {{ color: {accent}; }}
.card {{ background: #151819; border: 2px solid #23282A; border-radius: 16px; padding: 18px; }}
.card.selected {{ border-color: {accent}; background: #182022; }}
.card-title {{ font-size: 19px; font-weight: bold; }}
entry {{ background: #151819; color: #FFFFFF; border: 1px solid #2D3335; border-radius: 10px; padding: 9px 12px; min-height: 22px; }}
entry:focus {{ border-color: {accent}; }}
button {{ background: #1E2325; color: #FFFFFF; border: none; border-radius: 12px; padding: 10px 26px; }}
button:hover {{ background: #2A3134; }}
button.primary {{ background: {accent}; color: #0B0B0B; font-weight: bold; }}
button.primary:hover {{ background: {accent}; opacity: 0.9; }}
checkbutton, radiobutton {{ color: #E8ECEC; }}
combobox button {{ padding: 8px 12px; }}
scrolledwindow {{ background: transparent; }}
"""


# ---------------------------------------------------------------- the wizard
class Wizard(Gtk.Window):
    def __init__(self, windowed=False):
        super().__init__(title="EverestOS Setup")
        self.st = SetupState()
        self.t = Translator("en_US")
        self.page = 0
        self._css = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), self._css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self._user_edited_username = False
        self.set_default_size(1100, 720)
        if windowed:
            self.set_position(Gtk.WindowPosition.CENTER)
        else:
            self.set_decorated(False)
            self.fullscreen()
        self.connect("destroy", Gtk.main_quit)
        self.build()

    # ---- (re)build the whole UI; used again whenever the language changes
    def build(self):
        child = self.get_child()
        if child:
            self.remove(child)
            child.destroy()
        lang = self.st.lang
        Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL if lang.rtl else Gtk.TextDirection.LTR)
        self._css.load_from_data(css_for(self.st.accent).encode())
        self.set_title(self.t("app_title"))

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.get_style_context().add_class("root")
        root.set_margin_top(28)
        root.set_margin_bottom(28)
        root.set_margin_start(60)
        root.set_margin_end(60)

        header = Gtk.Box(spacing=16)
        logo = Gtk.DrawingArea()
        logo.set_size_request(44, 44)
        logo.connect("draw", lambda w, cr: draw_logo(cr, 0, 0, 44, self.st.accent) or False)
        header.pack_start(logo, False, False, 0)
        name = Gtk.Label(label="EverestOS")
        name.get_style_context().add_class("title")
        header.pack_start(name, False, False, 0)
        self.stepbar = Gtk.Box(spacing=8)
        header.pack_end(self.stepbar, False, False, 0)
        root.pack_start(header, False, False, 0)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_vexpand(True)
        for name_, builder in (("language", self.page_language), ("edition", self.page_edition),
                               ("name", self.page_name), ("color", self.page_color), ("menu", self.page_menu)):
            self.stack.add_named(builder(), name_)
        root.pack_start(self.stack, True, True, 24)

        self.status = Gtk.Label(label="")
        self.status.get_style_context().add_class("sub")
        root.pack_start(self.status, False, False, 4)

        footer = Gtk.Box(spacing=12)
        self.btn_back = Gtk.Button(label=self.t("back"))
        self.btn_back.connect("clicked", lambda *_: self.go(-1))
        self.btn_next = Gtk.Button(label=self.t("next"))
        self.btn_next.get_style_context().add_class("primary")
        self.btn_next.connect("clicked", lambda *_: self.go(1))
        footer.pack_start(self.btn_back, False, False, 0)
        footer.pack_end(self.btn_next, False, False, 0)
        root.pack_start(footer, False, False, 0)

        self.add(root)
        self.show_all()
        self.show_page(self.page)

    def rebuild_later(self):
        GLib.idle_add(self.build)

    # ---- navigation
    def show_page(self, index):
        self.page = max(0, min(index, len(PAGES) - 1))
        self.stack.set_visible_child_name(PAGES[self.page])
        self.btn_back.set_visible(self.page > 0)
        last = self.page == len(PAGES) - 1
        self.btn_next.set_label(self.t("continue_install") if last else self.t("next"))
        self.status.set_text(self.t("disk_note") if last else "")
        self.refresh_stepbar()

    def refresh_stepbar(self):
        for c in self.stepbar.get_children():
            self.stepbar.remove(c)
        labels = ("s_edition", "s_name", "s_color", "s_menu", "s_install")
        for i, key in enumerate(labels, start=1):
            lab = Gtk.Label(label="%d  %s" % (i, self.t(key)))
            ctx = lab.get_style_context()
            ctx.add_class("step")
            if self.page >= 1 and i == self.page:
                ctx.add_class("step-active")
            elif self.page >= 1 and i < self.page:
                ctx.add_class("step-done")
            self.stepbar.pack_start(lab, False, False, 0)
        self.stepbar.show_all()

    def go(self, delta):
        if delta > 0:
            if PAGES[self.page] == "name" and not self.validate_name():
                return
            if self.page == len(PAGES) - 1:
                self.launch_installer()
                return
        self.show_page(self.page + delta)

    # ---- page: language / keyboard / time zone
    def page_language(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        title = Gtk.Label(label=self.t("welcome_title"), xalign=0)
        title.get_style_context().add_class("title")
        sub = Gtk.Label(label=self.t("welcome_sub"), xalign=0)
        sub.get_style_context().add_class("sub")
        box.pack_start(title, False, False, 0)
        box.pack_start(sub, False, False, 0)

        grid = Gtk.Grid(column_spacing=24, row_spacing=12)
        grid.set_margin_top(18)

        self.cmb_lang = Gtk.ComboBoxText()
        for l in catalog.LANGUAGES:
            self.cmb_lang.append(l.code, "%s  (%s)" % (l.native, l.english) if l.native != l.english else l.native)
        self.cmb_lang.set_active_id(self.st.language)
        self.cmb_lang.connect("changed", self.on_language)

        self.cmb_kb = Gtk.ComboBoxText()
        for layout, opts, label in catalog.KEYBOARDS:
            self.cmb_kb.append(layout + "|" + opts, label)
        self.cmb_kb.set_active_id(self.st.keyboard_layout + "|" + self.st.keyboard_options)
        self.cmb_kb.connect("changed", self.on_keyboard)

        self.cmb_tz = Gtk.ComboBoxText()
        for tz in timezones():
            self.cmb_tz.append(tz, tz)
        self.cmb_tz.set_active_id(self.st.timezone)
        self.cmb_tz.connect("changed", lambda c: setattr(self.st, "timezone", c.get_active_id() or "UTC"))

        for row, (key, widget) in enumerate((("language", self.cmb_lang), ("keyboard", self.cmb_kb),
                                             ("timezone", self.cmb_tz))):
            lab = Gtk.Label(label=self.t(key), xalign=0)
            grid.attach(lab, 0, row, 1, 1)
            widget.set_hexpand(True)
            grid.attach(widget, 1, row, 1, 1)
        box.pack_start(grid, False, False, 0)
        return box

    def on_language(self, combo):
        code = combo.get_active_id()
        if not code or code == self.st.language:
            return
        self.st.language = code
        self.t.set_language(code)
        lang = self.st.lang
        self.st.keyboard_layout, self.st.keyboard_options = lang.xkb_layout, lang.xkb_options
        self.st.timezone = lang.timezone
        apply_live_keyboard(self.st)
        self.rebuild_later()  # never destroy the widget that is emitting the signal

    def on_keyboard(self, combo):
        ident = combo.get_active_id()
        if ident:
            layout, _, opts = ident.partition("|")
            self.st.keyboard_layout, self.st.keyboard_options = layout, opts
            apply_live_keyboard(self.st)

    # ---- page 1: edition
    def page_edition(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        title = Gtk.Label(label=self.t("edition_title"), xalign=0)
        title.get_style_context().add_class("title")
        box.pack_start(title, False, False, 0)
        row = Gtk.Box(spacing=24, homogeneous=True)
        self.cards = {}
        for key, ed in catalog.EDITIONS.items():
            card = Card(lambda k=key: self.choose_edition(k))
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            inner.pack_start(Preview(lambda cr, w, h, s=ed.search: draw_desktop_mock(cr, w, h, self.st.accent, s), 360, 200),
                             True, True, 0)
            tl = Gtk.Label(label=ed.title, xalign=0)
            tl.get_style_context().add_class("card-title")
            desc = Gtk.Label(label=self.t(ed.desc_key), xalign=0)
            desc.set_line_wrap(True)
            desc.get_style_context().add_class("sub")
            inner.pack_start(tl, False, False, 0)
            inner.pack_start(desc, False, False, 0)
            card.add(inner)
            row.pack_start(card, True, True, 0)
            self.cards[key] = card
        box.pack_start(row, True, True, 0)
        self.choose_edition(self.st.edition)
        return box

    def choose_edition(self, key):
        self.st.set_edition(key)
        for k, card in self.cards.items():
            card.set_selected(k == key)

    # ---- page 2: name
    def page_name(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        title = Gtk.Label(label=self.t("name_title"), xalign=0)
        title.get_style_context().add_class("title")
        box.pack_start(title, False, False, 0)
        grid = Gtk.Grid(column_spacing=24, row_spacing=12)
        grid.set_margin_top(10)
        self.e_full = Gtk.Entry(text=self.st.fullname)
        self.e_user = Gtk.Entry(text=self.st.username)
        self.e_host = Gtk.Entry(text=self.st.hostname)
        self.e_pw = Gtk.Entry(text=self.st.password)
        self.e_pw2 = Gtk.Entry(text=self.st.password)
        for e in (self.e_pw, self.e_pw2):
            e.set_visibility(False)
        self.e_full.connect("changed", self.on_fullname)
        self.e_user.connect("changed", lambda e: setattr(self, "_user_edited_username", True))
        rows = (("full_name", self.e_full), ("username", self.e_user), ("computer_name", self.e_host),
                ("password", self.e_pw), ("password2", self.e_pw2))
        for r, (key, widget) in enumerate(rows):
            grid.attach(Gtk.Label(label=self.t(key), xalign=0), 0, r, 1, 1)
            widget.set_hexpand(True)
            grid.attach(widget, 1, r, 1, 1)
        box.pack_start(grid, False, False, 0)
        self.lbl_err = Gtk.Label(label="", xalign=0)
        self.lbl_err.set_line_wrap(True)
        self.lbl_err.get_style_context().add_class("err")
        box.pack_start(self.lbl_err, False, False, 0)
        return box

    def on_fullname(self, entry):
        if not self._user_edited_username:
            self.e_user.set_text(suggest_username(entry.get_text()))
            self._user_edited_username = False  # set_text() fired "changed"; that was us, not the user

    def validate_name(self):
        self.st.fullname = self.e_full.get_text()
        self.st.username = self.e_user.get_text().strip()
        self.st.hostname = self.e_host.get_text().strip()
        self.st.password = self.e_pw.get_text()
        errors = self.st.validate_name_page(self.e_pw2.get_text())
        self.lbl_err.set_text("\n".join(self.t(k) for k in errors))
        return not errors

    # ---- page 3: colour
    def page_color(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        title = Gtk.Label(label=self.t("color_title"), xalign=0)
        title.get_style_context().add_class("title")
        sub = Gtk.Label(label=self.t("color_sub"), xalign=0)
        sub.get_style_context().add_class("sub")
        box.pack_start(title, False, False, 0)
        box.pack_start(sub, False, False, 0)
        body = Gtk.Box(spacing=40)
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        flow = Gtk.Grid(column_spacing=8, row_spacing=8)
        self.swatches = []
        for i, color in enumerate(catalog.PALETTE):
            sw = Swatch(color, self.choose_color)
            self.swatches.append(sw)
            flow.attach(sw, i % 5, i // 5, 1, 1)
        left.pack_start(flow, False, False, 0)
        custom = Gtk.ColorButton()
        rgba = Gdk.RGBA()
        rgba.parse(self.st.accent)
        custom.set_rgba(rgba)
        custom.connect("color-set", self.on_custom_color)
        left.pack_start(custom, False, False, 0)
        body.pack_start(left, False, False, 0)
        self.color_preview = Preview(
            lambda cr, w, h: draw_desktop_mock(cr, w, h, self.st.accent, self.st.search, with_window=True), 460, 290)
        body.pack_start(self.color_preview, True, True, 0)
        box.pack_start(body, True, True, 0)
        self.mark_swatches()
        return box

    def mark_swatches(self):
        for sw in self.swatches:
            sw.set_selected(sw.color.lower() == self.st.accent.lower())

    def choose_color(self, color):
        self.st.accent = color
        self._css.load_from_data(css_for(color).encode())  # the wizard itself takes the colour
        self.mark_swatches()
        self.color_preview.queue_draw()

    def on_custom_color(self, button):
        c = button.get_rgba()
        self.choose_color("#%02X%02X%02X" % (round(c.red * 255), round(c.green * 255), round(c.blue * 255)))

    # ---- page 4: start menu
    def page_menu(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        title = Gtk.Label(label=self.t("menu_title"), xalign=0)
        title.get_style_context().add_class("title")
        box.pack_start(title, False, False, 0)
        body = Gtk.Box(spacing=36)
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        left.pack_start(Gtk.Label(label=self.t("menu_style"), xalign=0), False, False, 0)
        style_row = Gtk.Box(spacing=16)
        r_list = Gtk.RadioButton.new_with_label_from_widget(None, self.t("menu_list"))
        r_grid = Gtk.RadioButton.new_with_label_from_widget(r_list, self.t("menu_grid"))
        (r_grid if self.st.menu_style == "grid" else r_list).set_active(True)
        r_grid.connect("toggled", lambda b: self.set_menu_style("grid" if b.get_active() else "list"))
        style_row.pack_start(r_list, False, False, 0)
        style_row.pack_start(r_grid, False, False, 0)
        left.pack_start(style_row, False, False, 0)

        left.pack_start(Gtk.Label(label=self.t("menu_pinned"), xalign=0), False, False, 0)
        pin_grid = Gtk.Grid(column_spacing=18, row_spacing=2)
        self.pin_checks = {}
        for i, app in enumerate(catalog.apps_for(self.st.edition)):
            cb = Gtk.CheckButton(label=app.name)
            cb.set_active(app.key in self.st.menu_pinned)
            cb.connect("toggled", self.on_pin, app.key)
            pin_grid.attach(cb, i % 3, i // 3, 1, 1)
            self.pin_checks[app.key] = cb
        left.pack_start(pin_grid, False, False, 0)

        left.pack_start(Gtk.Label(label=self.t("menu_categories"), xalign=0), False, False, 0)
        cat_grid = Gtk.Grid(column_spacing=18, row_spacing=2)
        for i, cat in enumerate(catalog.MENU_CATEGORIES):
            cb = Gtk.CheckButton(label=self.t("cat_" + cat))
            cb.set_active(cat in self.st.menu_categories)
            cb.connect("toggled", self.on_category, cat)
            cat_grid.attach(cb, i % 4, i // 4, 1, 1)
        left.pack_start(cat_grid, False, False, 0)

        recent = Gtk.CheckButton(label=self.t("menu_recent"))
        recent.set_active(self.st.menu_recent)
        recent.connect("toggled", self.on_recent)
        left.pack_start(recent, False, False, 0)
        body.pack_start(left, True, True, 0)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        right.pack_start(Gtk.Label(label=self.t("preview"), xalign=0), False, False, 0)
        self.menu_preview = Preview(lambda cr, w, h: draw_menu_mock(cr, w, h, self.st), 340, 360)
        right.pack_start(self.menu_preview, False, False, 0)
        body.pack_start(right, False, False, 0)
        box.pack_start(body, True, True, 0)
        return box

    def set_menu_style(self, style):
        self.st.menu_style = style
        self.menu_preview.queue_draw()

    def on_pin(self, button, key):
        pins = [k for k in self.st.menu_pinned if k != key]
        if button.get_active():
            pins.append(key)
        self.st.menu_pinned = pins
        self.menu_preview.queue_draw()

    def on_category(self, button, cat):
        cats = [c for c in self.st.menu_categories if c != cat]
        if button.get_active():
            cats.append(cat)
        self.st.menu_categories = [c for c in catalog.MENU_CATEGORIES if c in cats]
        self.menu_preview.queue_draw()

    def on_recent(self, button):
        self.st.menu_recent = button.get_active()
        self.menu_preview.queue_draw()

    # ---- step 5: hand over to Calamares
    def launch_installer(self):
        errors = self.st.validate()
        if errors:
            self.status.set_text(", ".join(errors))
            return
        runtime = os.environ.get("XDG_RUNTIME_DIR", "/tmp")
        path = os.path.join(runtime, "everestos-setup.json")
        self.st.save(path)
        self.status.set_text(self.t("starting_installer"))
        self.btn_next.set_sensitive(False)
        try:
            self.proc = subprocess.Popen(["sudo", "-n", "-E", LAUNCHER, path])
        except OSError:
            self.status.set_text(self.t("err_launch"))
            self.btn_next.set_sensitive(True)
            return
        self.hide()  # Calamares takes over the screen
        GLib.timeout_add(700, self.watch_installer)

    def watch_installer(self):
        if self.proc.poll() is None:
            return True
        try:
            os.remove(os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "everestos-setup.json"))
        except OSError:
            pass
        if os.path.exists(DONE_FLAG):
            Gtk.main_quit()
            return False
        # Installer closed without finishing: let the user start over or fix the problem.
        self.btn_next.set_sensitive(True)
        self.status.set_text(self.t("err_launch") if self.proc.returncode else "")
        self.show_all()
        self.show_page(len(PAGES) - 1)
        return False


# ---------------------------------------------------------------- helpers
def timezones():
    try:
        import zoneinfo
        zones = sorted(z for z in zoneinfo.available_timezones() if "/" in z and not z.startswith(("Etc/", "posix", "right")))
        return ["UTC"] + zones
    except Exception:  # noqa: BLE001
        return sorted({l.timezone for l in catalog.LANGUAGES})


def apply_live_keyboard(st):
    """Switch the live session's keyboard right away (best effort)."""
    cmd = ["setxkbmap", "-layout", st.keyboard_layout]
    if st.keyboard_options:
        cmd += ["-option", "", "-option", st.keyboard_options]
    try:
        subprocess.run(cmd, timeout=5, capture_output=True)
    except (OSError, subprocess.SubprocessError):
        pass


def main(argv=None):
    argv = argv or []
    win = Wizard(windowed="--windowed" in argv)
    win.show_all()
    Gtk.main()
    return 0
