-- Big centred clock + date drawn as an ASS overlay by mpv (used by /usr/lib/everestos/lockclock).
-- Placed in the upper half: xfce4-screensaver draws its password dialog in the centre of the screen.
-- os.date follows the session locale, so the weekday/month are in the user's language.
local function iround(x) return math.floor(x + 0.5) end

local function draw()
    local w, h = mp.get_osd_size()
    if not w or w <= 0 or h <= 0 then return end
    local t = os.date("%H:%M")
    local d = os.date("%A, %d %B")
    local ass = string.format(
        "{\\an5\\pos(%d,%d)\\bord0\\shad0\\blur0\\fnNoto Sans\\b0\\1c&HFFFFFF&\\fs%d}%s" ..
        "\\N{\\fs%d\\1c&HE6E6E6&}%s",
        iround(w / 2), iround(h * 0.25), iround(h * 0.19), t, iround(h * 0.045), d)
    mp.set_osd_ass(w, h, ass)
end

draw()
mp.add_periodic_timer(1, draw)
mp.register_event("file-loaded", draw)
mp.observe_property("osd-width", "number", function() draw() end)
