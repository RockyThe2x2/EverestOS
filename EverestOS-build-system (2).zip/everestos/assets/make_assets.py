#!/usr/bin/env python3
"""Generate every raster asset EverestOS needs from the logo geometry.

Usage:  make_assets.py <output-dir>

Only needs Pillow.  Output layout (relative to <output-dir>):
  icons/hicolor/<N>x<N>/apps/everestos-logo.png     N = 16 32 48 64 128 256 512
  icons/hicolor/scalable/apps/everestos-logo.svg
  backgrounds/wallpaper.jpg      (default desktop wallpaper: the supplied mountain photo)
  backgrounds/lock.jpg           (dimmed + softened copy: lock-screen clock background)
  backgrounds/greeter.jpg        (login screen background)
  backgrounds/wallpaper-teal.png (alternative generated wallpaper using the logo)
  plymouth/{logo.png,bar-bg.png,bar-fill.png}
  calamares/{logo.png,icon.png}
"""
import os
import shutil
import sys

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageOps

HERE = os.path.dirname(os.path.abspath(__file__))
TEAL = (0x2A, 0xBA, 0xA3)
SIZES = (16, 32, 48, 64, 128, 256, 512)

# Logo geometry on a 1080x1080 canvas: (x0, y0, x1, y1) inclusive-exclusive.
LOGO_RECTS = ((271, 15, 1071, 816), (12, 169, 197, 1067), (12, 891, 907, 1067))
LOGO_BOX = (12, 15, 1071, 1067)  # tight bounding box of the artwork


def logo(size, color=TEAL, pad=0.0):
    """Return an RGBA logo image `size` px square (tight artwork centred with `pad` margin fraction)."""
    ss = 4  # supersample for clean edges
    big = Image.new("L", (1080 * ss, 1080 * ss), 0)
    d = ImageDraw.Draw(big)
    for x0, y0, x1, y1 in LOGO_RECTS:
        d.rectangle([x0 * ss, y0 * ss, x1 * ss - 1, y1 * ss - 1], fill=255)
    bx0, by0, bx1, by1 = (v * ss for v in LOGO_BOX)
    big = big.crop((bx0, by0, bx1, by1))
    inner = int(size * (1 - 2 * pad))
    w, h = big.size
    scale = inner / max(w, h)
    big = big.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    solid = Image.new("RGBA", big.size, color + (255,))
    solid.putalpha(big)
    out.alpha_composite(solid, ((size - big.size[0]) // 2, (size - big.size[1]) // 2))
    return out


def gradient(size, top, bottom):
    w, h = size
    g = Image.linear_gradient("L").resize((w, h))
    a = Image.new("RGB", size, top)
    b = Image.new("RGB", size, bottom)
    return Image.composite(b, a, g)


def wallpaper(w=2560, h=1440):
    base = gradient((w, h), (10, 13, 14), (13, 38, 36))
    glow = Image.new("RGB", (w, h), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([int(w * 0.45), int(h * 0.15), int(w * 1.05), int(h * 0.95)], fill=(26, 120, 108))
    glow = glow.filter(ImageFilter.GaussianBlur(radius=int(h * 0.18)))
    base = ImageChops.add(base, glow.point(lambda v: int(v * 0.55)))
    mark = logo(int(h * 0.62), color=TEAL)
    alpha = mark.getchannel("A").point(lambda v: int(v * 0.10))
    mark.putalpha(alpha)
    base = base.convert("RGBA")
    base.alpha_composite(mark, (int(w * 0.62), int(h * 0.19)))
    return base.convert("RGB")


def photo_cover(src, w, h):
    """Scale + centre-crop the photo to exactly w x h (the source is only 1280x720, so upscale gently)."""
    im = ImageOps.fit(src.convert("RGB"), (w, h), Image.LANCZOS, centering=(0.5, 0.5))
    return im.filter(ImageFilter.UnsharpMask(radius=1.6, percent=60, threshold=2))


def lock_variant(src, w=1920, h=1080):
    """Soft, dim version so a big white clock stays readable on top of the bright snow."""
    im = photo_cover(src, w, h).filter(ImageFilter.GaussianBlur(radius=5))
    im = ImageEnhance.Brightness(im).enhance(0.52)
    im = ImageEnhance.Color(im).enhance(0.9)
    # darker towards the edges, slightly teal-tinted shadow: ties it to the brand colour
    vignette = Image.new("L", (w, h), 0)
    ImageDraw.Draw(vignette).ellipse([int(-w * 0.15), int(-h * 0.25), int(w * 1.15), int(h * 1.25)], fill=255)
    vignette = vignette.filter(ImageFilter.GaussianBlur(radius=int(h * 0.18)))
    shade = Image.new("RGB", (w, h), (6, 22, 22))
    return Image.composite(im, shade, vignette.point(lambda v: int(120 + v * 135 / 255)))


def bar(w, h, color):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(im).rounded_rectangle([0, 0, w - 1, h - 1], radius=h // 2, fill=color)
    return im


def main(out):
    for sub in ("icons/hicolor/scalable/apps", "backgrounds", "plymouth", "calamares"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
    for n in SIZES:
        d = os.path.join(out, "icons/hicolor/%dx%d/apps" % (n, n))
        os.makedirs(d, exist_ok=True)
        logo(n, pad=0.04).save(os.path.join(d, "everestos-logo.png"))
    shutil.copy(os.path.join(HERE, "logo.svg"), os.path.join(out, "icons/hicolor/scalable/apps/everestos-logo.svg"))

    wallpaper().save(os.path.join(out, "backgrounds/wallpaper-teal.png"), optimize=True)
    photo = Image.open(os.path.join(HERE, "wallpaper-mountain.jpg"))
    photo_cover(photo, 2560, 1440).save(os.path.join(out, "backgrounds/wallpaper.jpg"), quality=92, optimize=True)
    lock = lock_variant(photo)
    lock.save(os.path.join(out, "backgrounds/lock.jpg"), quality=90, optimize=True)
    lock.save(os.path.join(out, "backgrounds/greeter.jpg"), quality=90, optimize=True)

    with open(os.path.join(out, "backgrounds/wallpaper-teal.svg"), "w") as f:
        f.write(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">'
            '<defs><linearGradient id="g" x1="0" y1="0" x2="0.4" y2="1">'
            '<stop offset="0" stop-color="#0a0d0e"/><stop offset="1" stop-color="#0d2624"/></linearGradient></defs>'
            '<rect width="1920" height="1080" fill="url(#g)"/>'
            '<g opacity="0.10" fill="#2ABAA3" transform="translate(1190 205) scale(0.62)">'
            '<rect x="271" y="15" width="800" height="801"/><path d="M12 169H197V891H907V1067H12Z"/></g></svg>\n'
        )

    logo(256, pad=0.0).save(os.path.join(out, "plymouth/logo.png"))
    bar(220, 4, (60, 66, 68, 255)).save(os.path.join(out, "plymouth/bar-bg.png"))
    bar(220, 4, TEAL + (255,)).save(os.path.join(out, "plymouth/bar-fill.png"))
    logo(256, pad=0.0).save(os.path.join(out, "calamares/logo.png"))
    logo(64, pad=0.0).save(os.path.join(out, "calamares/icon.png"))
    print("assets written to", out)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
